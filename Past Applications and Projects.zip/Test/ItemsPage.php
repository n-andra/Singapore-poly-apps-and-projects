<html>
    <head> 
        <title>Bootstrap</title>
        <meta name= "viewport" content="width =device-width, initial-scale= 1.0" >
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="css/styles.css" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="css/CSS.css">
       
    </head><!-- this is the hrefs for the imported variables we use in the body -->
  
    <body>
        <div class ="navbar navbar-inverse navbar-static-top">
           <div class ="container">
                
                <a href= "#" class="navbar-brand"> Carlston's Wood Goods. "If it aint Wood, it aint good!"</a>
                
               <button class="navbar-toggle" data-toggle="collapse" data-target =".navHeaderCollapse">
                   <span class ="icon-bar"></span>
                   <span class ="icon-bar"></span>
                   <span class ="icon-bar"></span>
               </button>
               
                 <div class="collapse navbar-collapse navHeaderCollapse">
               
                   <ul class ="nav navbar-nav navbar-right">
                   
                       <li><a href = "About.php">About</a></li>
                       
                          <li class="dropdown active">
                            <a href="#" class = "dropdown-toggle" data-toggle ="dropdown"> Our Collection <b class="caret"></b></a>
                            <ul class="dropdown-menu">
                             <li><a href ="ItemsPage.php?type=Tables">Tables</a></li>
                             <li><a href ="ItemsPage.php?type=Lamps">Lamps</a></li>
                             <li><a href ="ItemsPage.php?type=Chairs">Chairs</a></li>
                            </ul>
                          </li>    
                       
                       
                        <li><a href = "#contact" data-toggle = "modal">Contact</a></li>
                   
                   </ul>
               
                 </div>
           </div> 
        </div> <!-- Header -->
        
        
        <div class="container">
            <div class="row">
                    <?php 
                    
            $type = isset($_GET['type'])? $_GET['type'] : 'table';     
            include 'productArray.php';
            if ($type == 'Tables'){
            for($i=0; $i<count($tableArray[1]); $i++){
                   // foreach ($tableArray[2] as $Description) {
                    
                    echo '<div class="col-md-3">';
                    echo '<div class="panel panel-default">';
                    echo '<div class="panel-body">';
                    
                
                    echo '<div class="page-header">';
                    echo "<h3><a name='product' method ='get' href=ItemsPage2.php"."?product=".$tableArray[4][$i]."&type=".$tableArray[1][$i]. ">". $tableArray[1][$i]. "</h3></a>"; //Header of the Article
                    echo '</div>';      
                    echo "<img class=featureImg"." "."src=".$tableArray[0][$i]."/>'";
                    echo "<p>". $tableArray[2][$i] ."</p>";   //Description of the Article
                    echo '</div>';
                    echo '</div>'; 
                    echo '</div>';
                         }
            } elseif ($type == 'Lamps'){
                  // }
           
            for($i=0; $i<count($lampArray[1]); $i++){
                   // foreach ($tableArray[2] as $Description) {
                    
                    echo '<div class="col-md-3">';
                    echo '<div class="panel panel-default">';
                    echo '<div class="panel-body">';
                    
                
                    echo '<div class="page-header">';
                    echo "<h3><a name='product' method ='get' href=ItemsPage2.php"."?product=".$lampArray[4][$i]."&type=".$lampArray[1][$i]. ">". $lampArray[1][$i]. "</h3></a>"; //Header of the Article
                    echo '</div>';      
                    echo "<img class=featureImg"." " ."src=".$lampArray[0][$i]."/>";
                    echo "<p>". $lampArray[2][$i] ."</p>";   //Description of the Article
                    echo '</div>';
                    echo '</div>'; 
                    echo '</div>';
                         }
            } else
                  // }
            
            for($i=0; $i<count($chairArray[1]); $i++){
                   // foreach ($tableArray[2] as $Description) {
                    
                    echo '<div class="col-md-3">';
                    echo '<div class="panel panel-default">';
                    echo '<div class="panel-body">';
                    
                
                    echo '<div class="page-header">';
                    echo "<h3><a name='product' method ='get' href=ItemsPage2.php"."?product=".$chairArray[4][$i]."&type=".$chairArray[1][$i]. ">". $chairArray[1][$i]. "</h3></a>"; //Header of the Article
                    echo '</div>';      
                    echo "<img class=featureImg"." " ."src=".$chairArray[0][$i]."/>";
                    echo "<p>". $chairArray[2][$i] ."</p>";   //Description of the Article
                    echo '</div>';
                    echo '</div>'; 
                    echo '</div>';
                         }
                  // }
            
?>
                             
                       
              </div>
            </div>   
        <div class="modal fade" id="contact" role="dialog" >
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4> Have an inquiry? Contact us!</h4>
                    </div>
                    <form action ="handleFeedback.php" method="post">
                      <div class="modal-body">
                          Name:<br/>
                          <input type ="text" name="username" />
                          Message : <br/>
                          <textarea name="msg" rows="4" cols="50"></textarea>
                      </div>
                      <div class="modal-footer">
                          <button class="btn btn-primary" type="submit"/>Send</button>
                          <button class="btn btn-warning" data-dismiss="modal">Close</button>
                      </div>
                    </form>   
                </div>  
                
            </div>    
            
        </div>
        
        
        <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"> </script>
        <script src="js/bootstrap.js"></script>
    </body>
</html>
         