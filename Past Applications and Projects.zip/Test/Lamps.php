<html>
    <head> 
        <title>Bootstrap</title>
        <meta name= "viewport" content="width =device-width, initial-scale= 1.0" >
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="css/styles.css" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="css/CSS.css">
       
    </head><!-- this is the hrefs for the imported variables we use in the body -->
  
    <body>
        <div class ="navbar navbar-inverse navbar-static-top">
           <div class ="container">
                
               <a href= "#" class="navbar-brand"> Valve </a>
                
               <button class="navbar-toggle" data-toggle="collapse" data-target =".navHeaderCollapse">
                   <span class ="icon-bar"></span>
                   <span class ="icon-bar"></span>
                   <span class ="icon-bar"></span>
               </button>
               
                 <div class="collapse navbar-collapse navHeaderCollapse">
               
                   <ul class ="nav navbar-nav navbar-right">
                   
                       <li><a href = "#">Home</a></li>
                       <li><a href = "#">About</a></li>
                       
                          <li class="dropdown active">
                            <a href="#" class = "dropdown-toggle" data-toggle ="dropdown"> Our Collection <b class="caret"></b></a>
                            <ul class="dropdown-menu">
                             <li><a href ="#">Computers</a></li>
                             <li><a href ="#">Appliances</a></li>
                             <li><a href ="#">Software</a></li>
                            </ul>
                          </li>    
                       
                       
                        <li><a href = "#contact" data-toggle = "modal">Contact</a></li>
                   
                   </ul>
               
                 </div>
           </div> 
        </div> <!-- Header -->
        
        
        <div class="container">
            <div class="row">
                   <?php 
                   include 'productArray.php';
            for($i=0; $i<count($lampArray[1]); $i++){
                   // foreach ($tableArray[2] as $Description) {
                    
                    echo '<div class="col-md-3">';
                    echo '<div class="panel panel-default">';
                    echo '<div class="panel-body">';
                    
                
                    echo '<div class="page-header">';
                    echo "<h3 name='product'>". $lampArray[1][$i]. "</h3>"; //Header of the Article
                    echo '</div>';      
                    echo '<img class="featureImg" src="$tableArray[0][$i]"/>';
                    echo "<p>". $lampArray[2][$i] ."</p>";   //Description of the Article
                    echo '</div>';
                    echo '</div>'; 
                    echo '</div>';
                         }
                  // }
            
?>
                             
                       
              </div>
            </div>    
         
       
          
             <!-- Body of the webpage, this one contains the categories of items sold -->