<?php
$imageset2 = array("img/image11.jpg", "img/image12.jpg", "img/image13.jpg");
$imageset3 = array("img/image21.jpg", "img/image22.jpg", "img/image23.jpg");
$featuredProduct = array(array ("Table D",
                               "The best table out there, made purely out of 100% Morning Wood",
                               "img/image4.jpg",
                                "4"),
                         array ("Lamp A",
                                "The best Lamp in Singapore, named only because of how Super it is.",
                                "img/image11.jpg",
                                "1"),
                         array ("Chair B",
                                "The only chair found in Atlantis, a really rare find.",
                                "img/image22.jpg",
                                "2")
                        );
                            
$productsSold = array(array('Tables',
                            'Lamps',
                            'Chairs'),
                      array('Browse through some great quality tables',
                            'The best quality Lamps',
                            'The best chairs downtown')
                            );
              //0           0    
 $tableArray =  array(array(          "img/image1.jpg", 
                                      "img/image2.jpg", 
                                      "img/image3.jpg", 
                                      "img/image4.jpg"),
              //           1     
                    array(        "Table A",
                                  "Table B", 
                                  "Table C",
                                  "Table D"),
              //           2
                    array(                "High Quality Wood", 
                                          "High End Trees", 
                                          "Burnt up used Wood", 
                                          "Morning Wood",
                                          ),
              //           3
                    array(           "$150", 
                                     "$250",
                                     "$350",
                                     "$120"),
                    array(           "1",
                                     "2",
                                     "3",
                                     "4")
                            );
 
 $lampArray = array(array("img/image11.jpg",
                          "img/image12.jpg",
                          "img/image13.jpg"
                          ),
                    array("Lamp A",
                          "Lamp B",
                          "Lamp C",
                          ),
                    array("Super Lamp",
                          "Mega Lamp",
                          "Ultra Lamp",
                          ),
                    array("$150", 
                          "$250",
                          "$350",
                          ),
                    array(           "1",
                                     "2",
                                     "3")
                    );

$chairArray = array(array("img/image21.jpg",
                          "img/image22.jpg",
                          "img/image23.jpg"
                          ),
                    array("Chair A",
                          "Chair B",
                          "Chair C"
                          ),
                    array("Best Chair",
                          "Really Good Chair",
                          "Supreme Chair"
                          ),
                    array("$150", 
                          "$250",
                          "$350",
                          ),
                    array(           "1",
                                     "2",
                                     "3")
    );

?>



