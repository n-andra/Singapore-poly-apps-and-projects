<?php
session_start();
?>
<html>
    <head> 
        <title>Bootstrap</title>
        <meta name= "viewport" content="width =device-width, initial-scale= 1.0" >
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="css/styles.css" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="css/CSS.css">
       
    </head><!-- this is the hrefs for the imported variables we use in the body -->
  
    <body>
        <div class ="navbar navbar-inverse navbar-static-top">
           <div class ="container">
                
                <a href= "#" class="navbar-brand">Islamic Finance Database</a>
                
               <button class="navbar-toggle" data-toggle="collapse" data-target =".navHeaderCollapse">
                   <span class ="icon-bar"></span>
                   <span class ="icon-bar"></span>
                   <span class ="icon-bar"></span>
               </button>
               
                 <div class="collapse navbar-collapse navHeaderCollapse">
               
                   <ul class ="nav navbar-nav navbar-right">
                   
                       <li><a href = "About.php">About</a></li>
                       
                          <li class="dropdown active">
                            <a href="#" class = "dropdown-toggle" data-toggle ="dropdown"> Our Collection <b class="caret"></b></a>
                            <ul class="dropdown-menu">
                                  <?php
         $con = mysqli_connect("localhost:3306", "IFDBAdmin", "12345678", "ifdb");
            $catquery = mysqli_query($con, "SELECT * FROM categories");
             while ($row = mysqli_fetch_array($catquery)){
                 echo "<li><a href="."CategoryPage.php?catID=".$row["CatID"].">".$row["CatName"]."</a></li>";
             }
             
                             ?>
                             <li><a href="OurCollection.php">Catalogue</a></li>
                            </ul>
                          </li> <?php
                         if (!isset($_SESSION['admin'])){
                       echo '<li><a href="loginPage.php">Login</a>';  
                         }?>
                       
                       
                        <li><a href = "#contact" data-toggle = "modal">Contact</a></li>
                   
                   </ul>
               
                 </div>
           </div> 
        </div> <!-- Header -->
        
        
        <div class="container">
            <?php
         $con = mysqli_connect("localhost:3306", "IFDBAdmin", "12345678", "ifdb");
          if (isset($_SESSION['admin'])){
         $welcomemsg = mysqli_query($con, "SELECT AdmName FROM admin "
             ."WHERE AdmName=".'"'.$_SESSION['admin'].'"');
            while ($row =  mysqli_fetch_array($welcomemsg)){
            echo "Welcome Administrator " .$row['AdmName'] ."!<br/>";
            echo "<a href='addAdmin.php' class='btn btn-default'><span class='glyphicon glyphicon-plus'></span></a>";  //change to add admin and - admin
            echo"<a href='deleteAdmin.php' class='btn btn-default'><span class='glyphicon glyphicon-minus'></span></a>"; //need to change to delete
            echo "<button type='button' class='btn btn-default'><strong>Administrator:</strong> " . $row['AdmName'] . "</button>";
            echo"<a href='editAdminDetails.php' class='btn btn-default'><span class='glyphicon glyphicon-pencil'></span> Edit</a>";// require edit function
            echo"<a href='adminHandleLogout.php' class='btn btn-default'><span class='glyphicon glyphicon-log-out'></span>Logout</a>";
            echo"<a href='viewFeedback.php' class='btn btn-default'><span class='glyphicon glyphicon-envelope'></span>View Feedback</a>";
            echo"<a href='insertProduct.php' class='btn btn-success btn pull-right'><span class='glyphicon glyphicon-plus'></span> Add Product</a>";
            echo "<br/><br/>";
            }
         }
         else {
             
         }
         ?>
            <div class="row">
                    <?php 
            $catID = isset($_GET['catID'])? $_GET['catID'] : 'none';
            $catRetriever = "SELECT * FROM `categories` WHERE `CatID` = $catID";
            $catChecker = mysqli_query($con, $catRetriever);
            while($row = mysqli_fetch_array($catChecker)){
                $catIDDisplay = $row['CatID'];
            if ($catID == $catIDDisplay){
                $query1 = mysqli_query($con, "SELECT * FROM " .$row['CatType']);
                while ($row = mysqli_fetch_array($query1)){
                echo '<div class="col-md-12">';
                echo '<div class="panel panel-default">';
                echo '<div class="panel-body">';
                echo '<div class="page-header">';
                echo "<h3 name='product' method ='get'"."?CatID=".$row['CatID']. "><b>". $row['Title']. "</b></h3>";    
                echo '</div>';      
                echo "<div class=col-md-5>";
                echo "<p>". $row['Body']  ."</p>";
                echo "</div>";
                echo "<div class=col-md-7>";
                echo "<img class=featureImg"." "."src="."img/halal-or-haram.png"." width=10%>";
                echo "</div>";         
                echo "<p>". $row['Body2'] ."</p>";   //Description of the Article
                echo "<p><b>Riba is also mentioned in a hadith and is considered one of the seven major sins.</b></p>";
                echo "<p>Knowing this, it is important that we understand the Halal and Haram as it one of the very basics in not only Islamic Finance, but Islam as well.</p>";
                 if (isset($_SESSION['admin'])){
            echo"<a href="."editProduct.php"."?recordid=".$row['recordid']."&catID=".$row['catID']." class='btn btn-default'><span class='glyphicon glyphicon-pencil'></span> Edit</a>";// require edit function
            echo"<a href="."deleteProduct.php"."?recordid=".$row['recordid']."&catID=".$row['catID']." class='btn btn-default'><span class='glyphicons glyphicons-remove-2'></span> Delete</a>";// require edit function
             } else {
              echo "</a>";
          }echo '</div>';
           echo '</div>'; 
           echo '</div>';  
           }
          }
        }
           
      
?>
                             
                       
              </div>
            </div>   
        <div class="modal fade" id="contact" role="dialog" >
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4> Have an inquiry? Contact us!</h4>
                    </div>
                    <form action ="handleFeedback.php" method="post">
                      <div class="modal-body">
                          Name:<br/>
                          <input type ="text" name="username" /><br/>
                          Message : <br/>
                          <textarea name="msg" rows="4" cols="50"></textarea>
                      </div>
                      <div class="modal-footer">
                          <button class="btn btn-primary" type="submit"/>Send</button>
                          <button class="btn btn-warning" data-dismiss="modal">Close</button>
                      </div>
                    </form>   
                </div>  
                
            </div>    
            
        </div>
        
        
        <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"> </script>
        <script src="js/bootstrap.js"></script>
    </body>
</html>
         