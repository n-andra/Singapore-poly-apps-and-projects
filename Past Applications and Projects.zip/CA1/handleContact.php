<html>
        <head>
                <title>RacketEmpire</title>
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <link href = "css/bootstrap.min.css" rel = "stylesheet">
                <link href = "css/styles.css" rel = "stylesheet">
                </head>
        <body>
            
            <div class="navbar navbar-inverse navbar-static-top">
                <div class ="container">
                    
                    <a href="#" class="navbar-brand">RacketEmpire</a>
                    
                    <button class="navbar-toggle" data-toggle="collapse" data-target=".navHeaderCollapse">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    
                    <div class="collapse navbar-collapse navHeaderCollapse">
                        
                        <ul class="nav navbar-nav navbar-right">
                            
                            <li><a href="AboutUs.php">About Us</a></li>
                            <li><a href="Products.php">Our Products</a></li>
                            <li class="active"><a href="#">Contact  Us</a></li>
                            
                        </ul>
                        
                    </div>
            </div>
            </div>
            
<?php
    $name = $_POST["name"];
    $email = $_POST["email"];
    $message = $_POST["message"];
    if (($name == "")||($email=="")){
        $message = 'Please fill up your contact information.';
        echo "<SCRIPT>
            alert('$message'); 
            window.history.back();
            </SCRIPT>";
    }
    else {
        $message = "Thank you $name! ";
        echo "<SCRIPT>
            alert('$message');
            </SCRIPT>";
        
$infile = fopen("contact.txt", "a") or exit("file not found") ; 
fwrite($infile ,"Name : $name" . "\r\n");
fwrite($infile ,"Email : $email" . "\r\n");
fwrite($infile ,"Message: $message" . "\r\n");

fclose($infile);

}

?>

                                <script src = "http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
                <script src = "js/bootstrap.js"></script>
        </body> 
</html>