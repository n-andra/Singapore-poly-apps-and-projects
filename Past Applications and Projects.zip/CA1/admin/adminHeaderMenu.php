<?php
echo "<h2>Administrator: " . $admininfo['name'] . "</h2><br />";
?>

[<a href='adminHomepage.php'>Home</a>] 
[<a href='insertStudentRequestForm.php'>Add Student</a>] 
[<a href='registerModuleRequest.php'>Register Module</a>] 
[<a href='adminHandleLogout.php'>logout</a>] 
<br /><br />

