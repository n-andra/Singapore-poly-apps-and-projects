<?php
// start a session
session_start();

// require the dbfunction.php file
require './dbfunction.php';

$loginid  = $_POST["loginid"];  // retrieve the adminid from login form
$password = $_POST["password"]; // retrieve the password from login form

$con = getDbConnect();          // invoke the getDbConnect() function to get a database connection

if (!mysqli_connect_errno($con)) { // connection to database is successful
    $sqlQueryStr =
            "SELECT * " .
            "FROM accountadmin AA " .
            "WHERE " .
            "AA.loginid = '$loginid' AND " .
            "AA.password = AES_ENCRYPT('$password','st2220')";

    //echo "#####$sqlQueryStr#####<br />";
    
    $result = mysqli_query($con, $sqlQueryStr); // execute the SQL query

    if ($row = mysqli_fetch_array($result)) {   // fetch the record
        $_SESSION['admininfo'] = $row;          // put the record into the session
        mysqli_close($con);                     // close database connection
        header('Location: adminAboutUs.php');  // redirect to the homepage.
    } else {
        mysqli_close($con);                      // close database connection
        header('Location: adminLoginPage.html'); // redirect to the login page.
    } 
} else {
    echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
?>
