<?php

function getDbConnect() {
    // get a database connect to database
    $con = mysqli_connect("localhost:3306", "waduser01", "st2220", "p1316014db");
    return $con;
}

?>
