<?php
require './checkAdminLoginStatus.php';
?>
<html>
        <head>
                <a href="AboutUs.php"><title>RacketEmpire</title></a>
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <link href = "../css/bootstrap.min.css" rel = "stylesheet">
                <link href = "../css/styles.css" rel = "stylesheet">
        </head>
        <body>
            
            <div class="navbar navbar-inverse navbar-static-top">
                <div class ="container">
                    
                    <a href="AboutUs.php" class="navbar-brand">RacketEmpire</a>
                    
                    <button class="navbar-toggle" data-toggle="collapse" data-target=".navHeaderCollapse">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    
                    <div class="collapse navbar-collapse navHeaderCollapse">
                        
                        <ul class="nav navbar-nav navbar-right">
                            
                            <li><a href="adminAboutUs.php">About Us</a></li>
                            <li class="active"><a href="adminProducts.php">Our Products</a></li>
                            <li><a href="ContactUs.php">Contact Us</a></li>
                            
                        </ul>
                        
                    </div>
            </div>
                
            </div>
            
             <div class="container">
            <?php
        
        
                   //<a href="#" class="btn btn-default">Default text here</a>
            echo "<a href='' class='btn btn-default'><span class='glyphicon glyphicon-plus'></span></a>";  //change to add admin and - admin
            echo"<a href='' class='btn btn-default'><span class='glyphicon glyphicon-minus'></span></a>"; //need to change to delete
            echo "<button type='button' class='btn btn-default'><strong>Administrator:</strong> " . $admininfo['name'] . "</button>";
            echo"<a href='' class='btn btn-default'><span class='glyphicon glyphicon-pencil'></span> Edit</a>";// require edit function
            echo"<a href='adminHandleLogout.php' class='btn btn-default'><span class='glyphicon glyphicon-log-out'></span>Logout</a>";
            echo"<a href='insertProduct.php' class='btn btn-success btn pull-right'><span class='glyphicon glyphicon-plus'></span> Add Product</a>";
            echo "<br/><br/>";
                        
                    $con = mysqli_connect("localhost:3306", "waduser01", "st2220", "p1316014db");

           if (mysqli_connect_errno($con)) {
               echo "Failed to connect to MySQL: " . mysqli_connect_error();
           } else {
                   if(isset($_GET['category'])){
               $result = mysqli_query($con,"SELECT * FROM products");

               while($row = mysqli_fetch_array($result)) {
                       $category = $_GET['category'];


                   if($category == $row['categorycode']){
                   echo "<div class='col-md-3'>";
                   //  echo "<div class='list-group'>";
                   echo "<div class='thumbnail'>";

                   echo  "<p class='text-primary text-center'><strong>" . $row['title'] . "</strong><br />";
                   echo  "<a href='adminmoreDetails.php?moreDetails=" . $row['productid']  . "' ><img src='../img/" . $row['imgfile']. "' width='70%' />";
                   echo  $row['price'] . "<br />";

                   echo "</div>";
                   echo "</div>";

               }
               }
           }
               mysqli_close($con);
           }
        
//        include 'productData.php';
//        if (isset($_GET['category'])){
//            
//            if(isset($productArr[$_GET['category']])){
//                $a = $productArr[$_GET['category']];
//                
//                foreach($a as $stick=> $name){
//                    echo"<div class='col-md-3'>";
//                    echo "<div class='thumbnail'>";
//                    foreach($name as $grip=>$string){
//                        if ($grip=="name"){
//                            echo "<p class='text-center'>$string</p>";
//                        }
//                            else if($grip =="imgfile"){
//                                echo "<a href='moreDetails.php?moreDetails=$stick'><img src='img/$string' width='80%'></a>";
//                            }
//                                else if ($grip == "price"){
//                                    echo "<p class='text-center'><strong>$string</strong></p>";
//                                }
//                                else{
//                                    echo "<div class='$string'>";
//                                }
//                            
//                        
//                    
//                }
//                echo"</div>";
//                echo"</div>";
//            }
//            
//            }  
//        }
        ?>
            </div>
                                   <div class="navbar navbar-default navbar-fixed bottom">
                
                <div class="container">
                    <p class="navbar-text pull-right">Site Built By Goh</p>
                    <a href="http://facebook.com" class="navbar-btn btn-info btn pull-left ">Like us on Facebook</a>
                    </div>
            </div>
                   <script src = "http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
                <script src = "../js/bootstrap.js"></script>
                
        </body> 
</html>