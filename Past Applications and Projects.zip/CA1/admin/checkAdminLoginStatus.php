<?php
// start a session
session_start();

if (isset($_SESSION['admininfo'])) {     // admininfo exist in session
    $admininfo = $_SESSION['admininfo']; // get admininfo from session
} else {
    header('Location: adminLoginPage.html');  // redirect to the login page.
} 
?>
