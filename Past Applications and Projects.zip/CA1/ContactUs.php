<html>
        <head>
                <a href="AboutUs.php"><title>RacketEmpire</title></a>
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <link href = "css/bootstrap.min.css" rel = "stylesheet">
                <link href = "css/styles.css" rel = "stylesheet">
                 <style>
            #box {
            border: 1px solid transparent;
            position: absolute;
            left:0;
            right:0;
            margin: auto;
            text-align: center;
            }
            #contacts{
            position: relative;
            text-align:center;
            margin:auto;
            padding:auto;
            }
            #contacts label{
                display:block;
                position:relative; 
            }
            #nameinput,#emailinput{
                width:20em;
            }
        </style>  
        </head>
        <body>
            
            <div class="navbar navbar-inverse navbar-static-top">
                <div class ="container">
                    
                    <a href="AboutUs.php" class="navbar-brand">RacketEmpire</a>
                    
                    <button class="navbar-toggle" data-toggle="collapse" data-target=".navHeaderCollapse">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    
                    <div class="collapse navbar-collapse navHeaderCollapse">
                        
                        <ul class="nav navbar-nav navbar-right">
                            
                            <li><a href="AboutUs">About Us</a></li>
                            <li><a href="Products.php">Our Products</a></li>
                            <li class="active"><a href="#">Contact  Us</a></li>
                            
                        </ul>
                        
                    </div>
            </div>
            </div>
            
            <div id="box">
                <br><br>
                <h1>Contact Us</h1>
                <br>
                <form name="ContactUs" id="ContactUs" action="handleContact.php" method="post"> 
                <fieldset id="contacts">
                <label>Name:<input type="text" name="name" id="nameinput" placeholder="Full Name"/></label>
                <label>Email:<input type="email" name="email" id="emailinput" placeholder="yahoo@abc.com"/></label>
                <label>Message:<textarea id="message" name="message" rows="5" cols="55"/></textarea></label>
            </fieldset>
                         <input type="submit" name="submit" value="Submit Form"><br>
            <br>
        </form>
        </div>
            

                    <script src = "http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
                <script src = "js/bootstrap.js"></script>
        </body> 
</html>