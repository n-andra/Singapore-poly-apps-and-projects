<!DOCTYPE html>
<html>
        <head>
                <title>Bootstrap 3</title>
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <link href = "css/bootstrap.min.css" rel = "stylesheet">
                <link href = "css/styles.css" rel = "stylesheet">
        </head>
        <body>
               
                <div class = "navbar navbar-inverse navbar-static-top">
                        <div class = "container">
                               
                                <a href = "#" class = "navbar-brand">Tech Site</a>
                               
                                <button class = "navbar-toggle" data-toggle = "collapse" data-target = ".navHeaderCollapse">
                                        <span class = "icon-bar"></span>
                                        <span class = "icon-bar"></span>
                                        <span class = "icon-bar"></span>
                                </button>
                               
                                <div class = "collapse navbar-collapse navHeaderCollapse">
                               
                                        <ul class = "nav navbar-nav navbar-right">
                                       
                                                <li class = "active"><a href = "#">Home</a></li>
                                                <li><a href = "#">Blog</a></li>
                                                <li class = "dropdown">
                                                       
                                                        <a href = "#" class = "dropdown-toggle" data-toggle = "dropdown">Social Media <b class = "caret"></b></a>
                                                        <ul class = "dropdown-menu">
                                                                <li><a href = "#">Twitter</a></li>
                                                                <li><a href = "#">Facebook</a></li>
                                                                <li><a href = "#">Google+</a></li>
                                                                <li><a href = "#">Instagram</a></li>
                                                        </ul>
                                               
                                                </li>
                                                <li><a href = "#">About</a></li>
                                                <li><a href = "#contact" data-toggle="modal">Contact</a></li>
                                       
                                        </ul>
                               
                                </div>
                               
                        </div>
                </div>
               
        <div class = "container">
                     <div class = "row">
                   
                        <div class = "col-lg-9">
                       
                            <div class = "panel panel-default">
                           
                                <div class = "panel-body">
                                   
                                    <div class = "page-header">
                                        <h3>Whatever you want <small>Posted on July 26th</small></h3>
                                    </div>
                                   
                                    <img class = "featuredImg" src = "img/motox.jpg" width = "100%">
                                   
                                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam imperdiet varius ligula vel interdum. Donec ut sapien nec eros pellentesque viverra vitae quis sem. Cras odio lorem, commodo mollis consequat nec, tempor vel sapien. Integer odio magna, luctus nec laoreet ut, rutrum vitae diam. Vivamus ullamcorper tortor in lectus accumsan, sed congue mi facilisis. Sed mi arcu, egestas vel turpis sed, feugiat laoreet nibh. Duis sit amet tincidunt urna. Nunc elementum elementum mauris quis feugiat. Phasellus pretium nunc sed ipsum adipiscing rhoncus. Vestibulum nec tortor sed ligula ornare lacinia. Nullam a turpis magna. Vivamus at interdum erat. Vestibulum bibendum lorem in feugiat ultricies. Fusce consequat eu risus sit amet vehicula. Maecenas auctor odio ipsum. Phasellus convallis est eu cursus lacinia.</p>
                                   
                                    <h4>A heading</h4>
                                   
                                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam imperdiet varius ligula vel interdum. Donec ut sapien nec eros pellentesque viverra vitae quis sem. Cras odio lorem, commodo mollis consequat nec, tempor vel sapien. Integer odio magna, luctus nec laoreet ut, rutrum vitae diam. Vivamus ullamcorper tortor in lectus accumsan, sed congue mi facilisis. Sed mi arcu, egestas vel turpis sed, feugiat laoreet nibh. Duis sit amet tincidunt urna. Nunc elementum elementum mauris quis feugiat. Phasellus pretium nunc sed ipsum adipiscing rhoncus. Vestibulum nec tortor sed ligula ornare lacinia. Nullam a turpis magna. Vivamus at interdum erat. Vestibulum bibendum lorem in feugiat ultricies. Fusce consequat eu risus sit amet vehicula. Maecenas auctor odio ipsum. Phasellus convallis est eu cursus lacinia.</p>
                                   
                                   
                                </div>
                           
                            </div>
                       
                        </div>
                               
                                <div class = "col-lg-3">
                           
                            <div class = "list-group">
                                <a href = "#" class = "list-group-item active">
                                    <h4 class = "list-group-item-heading">Lorem ipsum</h4>
                                    <p class = "list-group-item-text">Fusce consequat eu risus sit amet vehicula. Maecenas auctor odio ipsum. Phasellus convallis est eu cursus lacinia.</p>
                                </a>
                                <a href = "#" class = "list-group-item">
                                    <h4 class = "list-group-item-heading">Lorem ipsum</h4>
                                    <p class = "list-group-item-text">Fusce consequat eu risus sit amet vehicula. Maecenas auctor odio ipsum. Phasellus convallis est eu cursus lacinia.</p>
                                </a>
                                <a href = "#" class = "list-group-item">
                                    <h4 class = "list-group-item-heading">Lorem ipsum</h4>
                                    <p class = "list-group-item-text">Fusce consequat eu risus sit amet vehicula. Maecenas auctor odio ipsum. Phasellus convallis est eu cursus lacinia.</p>
                                </a>
                                <a href = "#" class = "list-group-item">
                                    <h4 class = "list-group-item-heading">Lorem ipsum</h4>
                                    <p class = "list-group-item-text">Fusce consequat eu risus sit amet vehicula. Maecenas auctor odio ipsum. Phasellus convallis est eu cursus lacinia.</p>
                                </a>
                            </div>
                           
                        </div>
                       
                      </div>
                   
                </div>
               
                <div class = "navbar navbar-default navbar-fixed-bottom">
               
                        <div class = "container">
                                <p class = "navbar-text pull-left">Site Built By Neil Rowe</p>
                                <a href = "http://youtube.com/codersguide" class = "navbar-btn btn-danger btn pull-right">Subscribe on YouTube</a>
                        </div>
               
                </div>
               
                <div class = "modal fade" id = "contact" role = "dialog">
                    <div class = "modal-dialog">
                        <div class = "modal-content">
                            <div class = "modal-header">
                                <h4>Contact Tech Site</h4>
                            </div>
                            <div class = "modal-body">
                                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.</p>
                            </div>
                            <div class = "modal-footer">
                        <a class = "btn btn-default" data-dismiss = "modal">Close</a>    
                                <a class = "btn btn-primary" data-dismiss = "modal">Close</a>
                            </div>
                        </div>
                    </div>
                </div>
               
                <script src = "http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
                <script src = "js/bootstrap.js"></script>
               
        </body>
</html>