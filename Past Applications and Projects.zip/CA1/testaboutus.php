<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
        <head>
        <a href="AboutUs.php"><title>RacketEmpire</title></a>
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <link href = "css/bootstrap.min.css" rel = "stylesheet">
                <link href = "css/styles.css" rel = "stylesheet">
        </head>
        <body>
            
            <div class="navbar navbar-inverse navbar-static-top">
                <div class ="container">
                    
                    <a href="#" class="navbar-brand">RacketEmpire</a>
                    
                    <button class="navbar-toggle" data-toggle="collapse" data-target=".navHeaderCollapse">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    
                    <div class="collapse navbar-collapse navHeaderCollapse">
                        
                        <ul class="nav navbar-nav navbar-right">
                            <li class="active"><a href="AboutUs.php">About Us</a></li>
                            <li><a href="Products.php">Our Products</a></li>
                            <li><a href="ContactUs.php">Contact Us</a></li>
                            
                        </ul>
                        
<!--                        <table>
            <tr>
                <td>Email</td>
                <td>: <input type="text" name="adminid" /></td>    
            </tr>
            <tr>
                <td>Password</td>
                <td>: <input type="password" name="password" /></td>    
            </tr>
            <tr>
                <td>&nbsp;</td>
                <td align="right"><input type="submit" name="submit" value="login"/></td>    
            </tr>
        </table>-->
                        
                    </div>
            </div>
                
            </div>
            
            
            <div class="container">
            <div class="row">
                
                <div class="col-lg-9"> 
                    <div class="panel panel-default">
                        <div class="panel-body">
                            
                            <div class="page-header">
                                <h3>About Us</h3>
                            </div>
                            
                            <img class="featureImg" src="img/lcw.jpg" width="100%">
                            <p>RacketEmpire is a newly formed e-commerce sporting goods retailer. We are part Singapore Polytechnic.</p>
                            <p>Our aim is to provide athletes with high quality equipment to bring out their best in the game.</p>
                            <p>E-commerce is the way forward for future generations of athletes</p>
                            <p>You'll find me at the top the podium with medeals wearing the best equipment i could have. Be it on courts, fields, we hoped all athletes at all levels could dominate the game</p>
                        </div>


                    </div>
            </div>
                
                                
                <div class="col-lg-3">
                    <div class="list-group">
                            <h4>Featured Products</h4>
                            <p>Check out our latest collection of rackets, shoes, and shirts!
                        </div>
        
                        
                        <?php
                        
                        $con = mysqli_connect("localhost:3306", "GZ", "1234567890", "ca2");

                        if (mysqli_connect_errno($con)) {
                            echo "Failed to connect to MySQL: " . mysqli_connect_error();
                                } else {
                            $result = mysqli_query($con,"SELECT * FROM featured");
   
                                 while($row = mysqli_fetch_array($result)) {
//                                    echo "<div class='col-md-3'>";
//                                     echo "<div class='thumbnail'>";
        
                                     echo "<p class='text-primary text-center'><strong>" . $row['title'] . "</strong></p>";
                                        echo '<img src="img/'.$row['imgfile'].'" width="40%">';
                                        //echo "<p class='text-warning text-center'><strong>" . $row['price'] . "</a></strong></p>";

//                                        echo "</div>";
//                                        echo "</div>";
                                    }
                                    mysqli_close($con);
                                }

                        
                        
                        ?>
            </div>
            </div>
                
            </div>

            
                    
            <div class="navbar navbar-default navbar-fixed bottom">
                
                <div class="container">
                    <p class="navbar-text pull-right">Site Built By Goh</p>
                    <a href="http://facebook.com" class="navbar-btn btn-info btn pull-left ">Like us on Facebook</a>
                    </div>
            </div>
                
            
        <script src = "http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
                <script src = "js/bootstrap.js"></script>
        </body> 
</html>
 
           