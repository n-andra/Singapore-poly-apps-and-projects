      <?php
        
      
        $categoryArr = [
            
            "rackets" => ["title" => "Rackets", "imgfile" => "r.jpg", "desc"=>"Check out our latest model of rackets" ],
            "shoes" => ["title"=> "Shoes", "imgfile"=>"sh.jpg", "desc"=>"Our latest model of shoes"],
            "apparels" => ["title" => "Apparels", "imgfile" => "ap.jpg", "desc"=>"Our latest model of shirts and pants"],
            "bags" => ["title" => "Bags", "imgfile" =>"bags.jpg", "desc"=>"Our latest collection of bags"]
        ];
        
        $productArr = [
            "rackets" => [
                "r1" => ["name" => "ARCSABER 005", "imgfile" => "r1.jpg", "price"=>"SGD59.00" ],
                "r2" => ["name" => "VOLTRIC Z FORCE II LCW", "imgfile" => "r2.jpg", "price"=>"SGD240.00"],
                "r3" => ["name" => "VOLTRIC Z FORCE II", "imgfile" => "r3.jpg", "price"=>"SGD240.00"],
                "r4" => ["name" => "NANORAY Z-SPEED", "imgfile" => "r4.jpg", "price"=>"SGD240.00"],
                "r5" => ["name" => "ARCSABER FB", "imgfile" => "r5.jpg", "price"=>"SGD210.00"],
                "r6" => ["name" => "ARCSABER Z-SLASH", "imgfile" => "r6.jpg", "price"=>"SGD169.00"],
                "r7" => ["name" => "ARCSABER 8 DX   ", "imgfile" => "r7.jpg", "price"=>"SGD119.00"],
            ],
            "shoes" => [
                "sh1" => ["name" => "SHB 86 LTD", "imgfile" => "sh1.jpg", "price"=>"SGD64.90"],
                "sh2" => ["name"=> "SHB 01 LTD", "imgfile"=>"sh2.jpg", "price"=>"SGD114.90"],
                "sh3" => ["name"=> "SHB 01 LTD LCW", "imgfile"=>"sh3.jpg", "price"=>"SGD175.00"],
                "sh4" => ["name"=> "SHB F1 MX", "imgfile"=>"sh4.jpg", "price"=>"SGD99.90"],
                "sh5" => ["name"=> "EXCEED PLUS 503 PR", "imgfile"=>"sh5.jpg", "price"=>"SGD29.90"],
                "sh6" => ["name"=> "SHB 86EX", "imgfile"=>"sh6.jpg", "price"=>"SGD70.00"],
                "sh7" => ["name"=> "SHB SC5 EX", "imgfile"=>"sh7.jpg", "price"=>"SGD59.90"],
            ],
            "apparels" =>[
                "ap1" => ["name" => "LCW MEN'S GAME SHIRT", "imgfile"=>"ap1.jpg", "price"=>"SGD39.90"],
                "ap2" => ["name" => "YONEX JP SINGLET", "imgfile"=>"ap2.jpg", "price"=>"SGD20.00"],
                "ap3" => ["name" => "MALAYSIA MEN'S TEAM SHIRT", "imgfile"=>"ap3.jpg", "price"=>"SGD29.90"],
                "ap4" => ["name" => "YONEX SG SHIRT", "imgfile"=>"ap4.jpg", "price"=>"SGD19.90"],
                "ap5" => ["name" => "YONEX ASAIN GAMES SHIRT", "imgfile"=>"ap5.jpg", "price"=>"SGD29.00"],
                "ap6" => ["name" => "YONEX WORLD CHAMPIONSHIP SHIRT", "imgfile"=>"ap6.jpg", "price"=>"SGD19.90"],
                "ap7" => ["name" => "YONEX SP MODEL", "imgfile"=>"ap7.jpg", "price"=>"SGD19.90"],
                 
            ],
            "bags" =>[
                "b1" => ["name" => "JAPAN TOURNAMENT 9231 WEX", "imgfile"=>"b1.jpg", "price"=>"SGD55.00"],
                "b2" => ["name" => "JAPAN PRO BACKPACK 9312EX", "imgfile"=>"b2.jpg", "price"=>"SGD40.00"],
                "b3" => ["name" => "JAPAN PRO TOURNAMENT BAG", "imgfile"=>"b3.jpg", "price"=>"SGD114.90"],
                "b4" => ["name" => "YONEX BAG SBM--07A", "imgfile"=>"b4.jpg", "price"=>"SGD20.00"],
                "b5" => ["name" => "SPORTS BAG 1002B", "imgfile"=>"b5.jpg", "price"=>"SGD30.00"],
                "b6" => ["name" => "SPORTS BAG 7326 BT6", "imgfile"=>"b6.jpg", "price"=>"SGD40.00"],
                "b7" => ["name" => "TOURNAMENT BAG", "imgfile"=>"b7.jpg", "price"=>"SGD50.00"],
                
                
            ]
            
        ];
        
        
        $featuredArr = [
            "sh3" => ["name"=> "SHB 01 LTD LCW", "imgfile"=>"sh3.jpg", "price"=>"SGD175.00"],
            "r2" => ["name" => "VOLTRIC Z FORCE II LCW", "imgfile" => "r2.jpg", "price"=>"SGD240.00"],
            "b1" => ["name" => "JAPAN TOURNAMENT 9231 WEX", "imgfile"=>"b1.jpg", "price"=>"SGD55.00"],
        ];
      
      
      
       
?>