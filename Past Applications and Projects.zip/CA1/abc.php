<html>
        <head>
                <a href="AboutUs.php"><title>RacketEmpire</title></a>
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <link href = "css/bootstrap.min.css" rel = "stylesheet">
                <link href = "css/styles.css" rel = "stylesheet">
        </head>
        <body>
            
            <div class="navbar navbar-inverse navbar-static-top">
                <div class ="container">
                    <a href="AboutUs.php" class="navbar-brand">RacketEmpire</a>
                    
                    <button class="navbar-toggle" data-toggle="collapse" data-target=".navHeaderCollapse">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    
                    <div class="collapse navbar-collapse navHeaderCollapse">
                        
                        <ul class="nav navbar-nav navbar-right">
                            
                            <li><a href="AboutUs.php">About Us</a></li>
                            <li class="active"><a href="Products.php">Our Products</a></li>
                            <li><a href="ContactUs.php">Contact Us</a></li>
                            
                        </ul>
                        
                    </div>
            </div>
                
            </div>
            
                
                <div class="container">
<?php
$con = mysqli_connect("localhost:3306", "GZ", "1234567890", "ca2");

if (mysqli_connect_errno($con)) {
    echo "Failed to connect to MySQL: " . mysqli_connect_error();
} else {
        if(isset($_GET['products'])){
    $result = mysqli_query($con,"SELECT * FROM products");
          
    while($row = mysqli_fetch_array($result)) {
            $cb = $_GET['products'];
            //$bitch = $row['code'];
            
            
        if($cb == $row['title']){
        echo "<div class='col-md-3'>";
        //  echo "<div class='list-group'>";
        echo "<div class='thumbnail'>";
        echo  "<p class='text-primary text-center'><strong>" . $row['title'] . "</strong><br />";
        echo  "<a href='abc.php?item=" . $row['title']  . "' ><img src='img/" . $row['imgfile']. "' width='80%' />";
        echo  $row['info'] . "<br />";
        
        echo "</div>";
        echo "</div>";
        
    }
    }
}
    mysqli_close($con);
}
//}


?>
                    </div>
             
                           
                                <script src = "http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
                <script src = "js/bootstrap.js"></script>
        </body> 
</html>