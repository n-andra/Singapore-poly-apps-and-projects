<html>
        <head>
        <a href="AboutUs.php"><title>RacketEmpire</title></a>
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <link href = "css/bootstrap.min.css" rel = "stylesheet">
                <link href = "css/styles.css" rel = "stylesheet">
        </head>
        <body>
            
            <div class="navbar navbar-inverse navbar-static-top">
                <div class ="container">
                    <a href="AboutUs.php" class="navbar-brand">RacketEmpire</a>
                    
                    <button class="navbar-toggle" data-toggle="collapse" data-target=".navHeaderCollapse">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    
                    <div class="collapse navbar-collapse navHeaderCollapse">
                        
                        <ul class="nav navbar-nav navbar-right">
                            
                            <li><a href="AboutUs.php">About Us</a></li>
                            <li class="active"><a href="Products.php">Our Products</a></li>
                            <li><a href="ContactUs.php">Contact Us</a></li>

                                                        <li class="dropdown" id="menuLogin">
                        <a class="dropdown-toggle" href="#" data-toggle="dropdown" id="navLogin">Sign In</a>
                        <div class="dropdown-menu" style="padding:15px;">
                            <form action="./admin/adminHandleLogin.php" method="post"> 
                          <Label>Username:<input name="loginid" id="username" type="text" placeholder="Username"></label>
                          <label>Password:<input name="password" id="password" type="password" placeholder="Password"><br></label>
                <button type="submit" id="btnLogin" class="btn"><span class="glyphicon glyphicon-log-in"></span> Login</button>
              </form>
            </div>
          </li>
                            
                        </ul>
                        
                    </div>
            </div>
                
            </div>
            
            
            <div class="container">
            <div class="row">
                
                <div class="col-lg-9"> 
                    <div class="panel panel-default">
                        <div class="panel-body">
                            
                            <div class="page-header">
                                <h3>About Us</h3>
                            </div>
                            
                            <img class="featureImg" src="img/lcw.jpg" width="100%">
                            <p>RacketEmpire is a newly formed e-commerce sporting goods retailer. We are part Singapore Polytechnic.</p>
                            <p>Our aim is to provide athletes with high quality equipment to bring out their best in the game.</p>
                            <p>E-commerce is the way forward for future generations of athletes</p>
                            <p>You'll find me at the top the podium with medeals wearing the best equipment i could have. Be it on courts, fields, we hoped all athletes at all levels could dominate the game</p>
                        </div>


                    </div>
            </div>
                
                
                                
<!--                <div class="col-lg-3">
                    <a href = "#" class = "list-group-item active">
                            <h4 class="list-group-item-heading">Featured Products</h4>
                            <p class="list-group-item">Check out our latest collection of rackets, shoes, and shirts!</p>
                    </a>
                        </div>-->
                
                 <div class = "col-lg-3">
                           
                            <div class = "list-group">
                                <a href = "#" class = "list-group-item active">
                                    <h4 class = "list-group-item-heading">Featured Products</h4>
                                    <p class = "list-group-item-text">Check out our latest collection of rackets, shoes, and shirts!</p>
                                </a>
        
                        
                        <?php
                        include 'productData.php';
                        
                         foreach ($featuredArr as $feature => $display){
                             foreach($display as $item => $shown){
                                 //echo"<div class='list-group>";
                                 if($item == 'name'){
                                     echo "<h5><strong>$shown</strong></h5>";
                                    // echo "</div>";
                                 }
                                 
                                 else if($item == "imgfile"){
                                     //echo"<div class='list-group>";
                                     echo "<a href='moreDetails.php?moreDetails=$feature'><img src='img/$shown' width='40%'></a>";
                                     //echo "</div>";
                                 }
                                 else {
                                    // echo"<div class='list-group>";
                                     echo "<div class='$shown'>";
                                     //echo "</div>";
                                     echo "</div>";
                                 }
                             }
                             //echo"</div>";
                         }
                        
                        
                        ?>
            </div>
            </div>
                
            </div>

            
                    
            <div class="navbar navbar-default navbar-fixed bottom">
                
                <div class="container">
                    <p class="navbar-text pull-right">Site Built By Goh</p>
                    <a href="http://facebook.com" class="navbar-btn btn-info btn pull-left ">Like us on Facebook</a>
                    </div>
            </div>
                
            
        <script src = "http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
                <script src = "js/bootstrap.js"></script>
        </body> 
</html>
 
           