<html>
        <head>
                <a href="AboutUs.php"><title>RacketEmpire</title></a>
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <link href = "css/bootstrap.min.css" rel = "stylesheet">
                <link href = "css/styles.css" rel = "stylesheet">
        </head>
        <body>
            
            <div class="navbar navbar-inverse navbar-static-top">
                <div class ="container">
                    <a href="AboutUs.php" class="navbar-brand">RacketEmpire</a>
                    
                    <button class="navbar-toggle" data-toggle="collapse" data-target=".navHeaderCollapse">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    
                    <div class="collapse navbar-collapse navHeaderCollapse">
                        
                        <ul class="nav navbar-nav navbar-right">
                            
                            <li><a href="AboutUs.php">About Us</a></li>
                            <li class="active"><a href="Products.php">Our Products</a></li>
                            <li><a href="ContactUs.php">Contact Us</a></li>
                            <li><a href="LoginPage.php">Sign in</a></li
                            
                        </ul>
                        
                    </div>
            </div>
                
            </div>
            
            
            <h3>Welcome to the Almighty Page!</h3>
        <form action="handleLogin.php" method="post">
        <table>
            <tr>
                <td>Id</td>
                <td>: <input type="text" name="adminid" /></td>    
            </tr>
            <tr>
                <td>Password</td>
                <td>: <input type="password" name="password" /></td>    
            </tr>
            <tr>
                <td>&nbsp;</td>
                <td align="right"><input type="submit" name="submit" value="Login"/></td>    
            </tr>
        </table>
        </form>
            
            
            
                                            <script src = "http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
                <script src = "js/bootstrap.js"></script>
        </body> 
</html>
            