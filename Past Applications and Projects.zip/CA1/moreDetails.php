<html>
        <head>
        <a href="AboutUs.php"><title>RacketEmpire</title></a>
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <link href = "css/bootstrap.min.css" rel = "stylesheet">
                <link href = "css/styles.css" rel = "stylesheet">
        </head>
        <body>
            
            <div class="navbar navbar-inverse navbar-static-top">
                <div class ="container">
                    
                    <a href="AboutUs.php" class="navbar-brand">RacketEmpire</a>
                    
                    <button class="navbar-toggle" data-toggle="collapse" data-target=".navHeaderCollapse">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    
                    <div class="collapse navbar-collapse navHeaderCollapse">
                        
                        <ul class="nav navbar-nav navbar-right">
                            
                            <li><a href="AboutUs.php">About Us</a></li>
                            <li class="active"><a href="Products.php">Our Products</a></li>
                            <li><a href="ContactUs.php">Contact Us</a></li>
                            
                        </ul>
                        
                    </div>
            </div>
                
            </div>
            <div class="container">
            
            <?php
            
            $con = mysqli_connect("localhost:3306", "waduser01", "st2220", "p1316014db");

           if (mysqli_connect_errno($con)) {
               echo "Failed to connect to MySQL: " . mysqli_connect_error();
           } else {
                   if(isset($_GET['moreDetails'])){
               $result = mysqli_query($con,"SELECT * FROM products");

               while($row = mysqli_fetch_array($result)) {
                   $product = $_GET['moreDetails'];


                   if($product == $row['productid']){
                   echo "<div class='col-md-3'>";
                   //  echo "<div class='list-group'>";
                   //echo "<div class='thumbnail'>";

                   echo  "<p class='text-primary text-center'><strong>" . $row['title'] . "</strong><br />";
                   //echo  "<a href='moreDetails.php?moreDetails=" . $row['productid']  . "' ><img src='img/" . $row['imgfile']. "' width='80%' />";
                   echo  $row['price'] . "<br />";

                   echo "</div>";
                   echo "</div>";

               }
               }
           }
               mysqli_close($con);
           }
               
               
//            include 'productData.php';
//             if (isset($_GET['moreDetails'])){
//             foreach($productArr as $item=>$product){
//                 
//            if(isset($product[$_GET['moreDetails']])){
//                $details = $product[$_GET['moreDetails']];
//            
//             
//                    foreach($details as $info=>$numbers){
//                             echo"<div class='col-md-4'>";
//                                 echo "<div class='panel-body'>";
//                                 echo "<div class='page-header'>";
//                        if($info =="imgfile"){
////                            echo "<div class='col-md-6'>";
//                            echo "<img src='img/$numbers' width = '50%'>";
//                            echo"</div>";
//                            echo "</div>";
//                            echo "</div>";
//                        }
//                        else if($info=="name"){
//                            echo"<div class='col-md-6'>";
//                            echo "<h3><strong>$numbers</strong></h3>";
//                            echo "</div>";
//                        }
//                        else if($info =="price"){ 
//                            echo"<div class='col-md-6'>";
//                            echo "<strong>$numbers</strong>";
//                            echo "</div>";
//                        }
//                        else{
//                            echo "<div class='col-md-6'>";
//                            echo "<div class='$numbers'>";
//                            echo "</div>";
//                            echo "</div>";
//                        }
//                    }
//                }
//                echo "</div>";
//            }
//                    }
            ?>
            </div>
            

                
                      
                                             <script src = "http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
                <script src = "js/bootstrap.js"></script>
                
        </body> 
</html>
            
