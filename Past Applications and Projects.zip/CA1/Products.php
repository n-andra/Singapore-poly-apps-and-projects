<html>
        <head>
                <a href="AboutUs.php"><title>RacketEmpire</title></a>
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <link href = "css/bootstrap.min.css" rel = "stylesheet">
                <link href = "css/styles.css" rel = "stylesheet">
        </head>
        <body>
            
            <div class="navbar navbar-inverse navbar-static-top">
                <div class ="container">
                    <a href="AboutUs.php" class="navbar-brand">RacketEmpire</a>
                    
                    <button class="navbar-toggle" data-toggle="collapse" data-target=".navHeaderCollapse">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    
                    <div class="collapse navbar-collapse navHeaderCollapse">
                        
                        <ul class="nav navbar-nav navbar-right">
                            
                            <li><a href="AboutUs.php">About Us</a></li>
                            <li class="active"><a href="Products.php">Our Products</a></li>
                            <li><a href="ContactUs.php">Contact Us</a></li>
                            
                        </ul>
                        
                    </div>
            </div>
                
            </div>
            
                
                <div class="container">
                 
                             <?php
                        $con = mysqli_connect("localhost:3306", "waduser01", "st2220", "p1316014db");

                        if (mysqli_connect_errno($con)) {
                            echo "Failed to connect to MySQL: " . mysqli_connect_error();
                        } else {
                            $result = mysqli_query($con,"SELECT * FROM category");

                            while($row = mysqli_fetch_array($result)) {
                                echo "<div class='col-md-3'>";
//                                echo "<div class='list-group'>";
                                echo "<div class='thumbnail'>";
                                echo "<p class='text-primary text-center'><strong>" . $row['title'] . "</strong></p>";
                                echo "<a href='productlist.php?category=" . $row['categorycode']  . "' ><img src='img/" . $row['imgfile']. "' width='65%' />";
                                echo "<p class='text-warning text-center'><strong>" . $row['description'] . "</a></strong></p>";
                                

                                echo "</div>";
                                echo "</div>";

                            }
                            mysqli_close($con);
                        }


                                            
                            
//                             include ('productData.php');
//                             
//                        foreach ($categoryArr as $category=>$desc){
//                                echo"<div class='col-md-3'>";
//                                echo "<div class='thumbnail'>";
//                          foreach ($desc as $name=>$value){
//                              if ($name=="title"){
//                                  echo "<p class='text-primary lead text-center'>$value</p>";
//                              }
//                              else if ($name=="imgfile"){
//                               echo"<a href='productlist.php?category=$category'><img src='img/$value' width='80%'></a>";
//                              }
//                              
//                              else if($name == "desc"){
//                                  echo "<p class ='text-center'>$value</p>";
//                              }
//                              else{
//                                  echo "<div class='$value'>";
//                                  echo "</div>";
//                              }
//                              }
//                              echo "</div>";
//                              echo "</div>";
//                          }
           ?>
                    
                </div>
             
                            
                                <script src = "http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
                <script src = "js/bootstrap.js"></script>
        </body> 
</html>
            