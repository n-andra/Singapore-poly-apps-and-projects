<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <form action ="handleTable.php" method ="post">
            Number of Rows<input type="number"  name="row" /><br/>
            Number of Columns<input type="number"  name="col" /><br/>
            <input type="submit" value="Go!" />
        </form>   
        
        <a href="handleTable.php?row=6&col=8">create a 6 x 8 Table </a><br/>
        <a href="handleTable.php?row=12&col=20">create a 12 x 20 Table </a><br/>
        <a href="handleTable.php">create a 5 x 5 Table </a><br/>
        <a href="handleTable.php?row=1&col=1">create a 1 x 1 Table </a><br/>
        
        
    </body>
</html>
