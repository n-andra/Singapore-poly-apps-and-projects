<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
      <?php
      
      $col = isset($_REQUEST['col'])? $_REQUEST['col'] : 5;
      $row = isset($_REQUEST['row'])? $_REQUEST['row'] : 5;
      ?>
        <table border ="1">
            <?php 
  
          for ($k=1; $k<=$row; $k++){ 
                  
                 echo "<tr>";
            
              for($i=1; $i<=$col; $i++){
                echo "<td>" . ($i * $k) . "</td>";
                }
            
                 echo "</tr>";
         
           
                }
              ?>
            
        </table>
        
    </body>
</html>
