<html>
    <body>

<?php

  $a=5; $b=3; $c=2; $d=8;
  $b += --$a * ++$c;
  /* b += --5 * ++2 
   * b = 3 + --5 * ++ 2
   * b = 3 + 4 * 3  
   * b = 15, a = 4, c = 3 */
  echo "$a $b $c $d <br />";
  
  if ($d % 4 == 2) {
      if ($a == 4) {
          echo "A<br />";
          } else {
               echo "B<br />";
      }
  } else { echo "C<br />";
    if ($c > 0) {
        echo "D<br />";
    } else if ($a > 0) {
        echo "E<br />";
    }
  }
?>

     </body>
</html>


