<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        
        <a href="example06.php?num=1"> Num is 1 </a><br/>
        <a href="example06.php?num=2"> Num is 2 </a><br/>
        <a href="example06.php?num=3"> Num is 3 </a><br/>
      
        
        
        
        <?php
        
        $num = isset($_GET['num'])? $_GET['num'] :0;
        
        switch ($num) {
            case 1 :
                echo "A";
               break;
           
            case 2 :
                echo "B";
              
          
            case 3 :
                echo "C";
               break;
           
            default :
                echo "D";
              
        }
        
   
        
        ?>
    </body>
</html>
