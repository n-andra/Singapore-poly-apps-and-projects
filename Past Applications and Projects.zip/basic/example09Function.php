<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
         
        
        function sumArray($x){
            $total = 0;
            
            // A for loop, to look for each element in the array and add it to the 
            foreach ($x as $value) {
                $total += $value;
            }
            
            return $total;
        }
        
        // Creating a three dimensional array (each additional bracket set creates another dimension)
        $numArr = [
        [1,2,3,4,5],
        [22,33],
        [99,88,77]
        ];
        
        // Creating a for loop, displays the sum of each array by counting the 
        // no. of values in the array
        for ( $i=0; $i < count($numArr); $i++ ){
        echo "sum of row $i is " . sumArray($numArr[$i]) . "<br />";
        };
        ?>
    </body>
</html>
