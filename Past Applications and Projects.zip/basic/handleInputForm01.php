<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
           $name = $_POST['username'];
           $yearOfBirth = $_POST['yob'];
           
           $age = date("Y") - $yearOfBirth;
        
           echo "$name, you are $age years old";
           
           ?>
    </body>
</html>
