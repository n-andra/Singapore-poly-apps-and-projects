
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>



        <?php
        include '../Advance/includeExample/menuNavBar.php';
        $row = isset($_GET['r']) ? $_GET['r'] : 5;

        for ($i = 0; $i <= $row; $i++) {
            print "hello $i <br/ >";
            echo 'hello $i <br />';
        }
        ?>


    </body>
</html>
