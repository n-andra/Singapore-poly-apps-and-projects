<html>
    <body>

<?php

date_default_timezone_set("Asia/Singapore");
$hour = date("H");

echo "Hour : $hour <br />";

if ($hour <12){
    echo "Good Morning!";}
   
    else if ($hour <20){
    
        echo "Good Afternoon!";}    
    else {
     echo "Good Night!";}

?>

     </body>
</html>


