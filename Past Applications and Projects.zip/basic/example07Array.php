<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
              
        
             ///               0     1      2        3
           $numberArr1 = array(6, "hello", 3.5, "eyyy brudda");
            // We're adding more here, you can do this in PHP but not java
           $numberArr1[4] = 100;
           $numberArr1[5] = "ajajaja";
           // If you want to fix a number to the end of the array
           $numberArr1[] = 50;
           // If you set this... the for loop below will not work, since there is no "6" to run.
           $numberArr1[20] = "world";
           
           
           echo $numberArr1[0];
           echo $numberArr1[1];
           echo $numberArr1[2];
           echo $numberArr1[3];
           echo "<br/>";
           for ($i=0; $i<=  count($numberArr1); $i++){
               echo $numberArr1[$i] . "<br/>";
           }
         // This new for loop must be doen.
           // For each item in the collection (in this case, numberArr1
           // represent it as the index $k pointing to the itemm
           
           foreach($numberArr1 as $k => $x ){
               echo "index : $k contains the value $x <br />";
           }
               
           echo"<br />";
           echo"<pre>";
           print_r($numberArr1);
           echo"</pre>";
          
           
           $numberArr2 =[4, 6 ,7 , "hello", "hahaha" , 5.5];   
         //  Lines 50 to 54 are only doable on PHP 5.4 and above
           
           echo "<pre>";
           print_r($numberArr2);
           echo "</pre>"
        ?>
    </body>
</html>
