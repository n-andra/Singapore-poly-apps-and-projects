<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
       // 1 2 3 4 5 6 7 8 9 
       //1. In a for loop you wanna ask yourself
       //  What is the end point?
       // What is the endpoint and complete the following
        
       // In the code below
       // As long as i has a start point, the code will carry on
        
        $x = isset($_GET['loop'])? $_GET['loop'] : 10;
        
        for ($i = 1; $i<=100; $i++  ) {
            echo "$i" . " " ;
            if ($i % $x == 0) {
            echo "<br/>";
                }
        }
        
        
        
        
        
        
        ?>
    </body>
</html>
