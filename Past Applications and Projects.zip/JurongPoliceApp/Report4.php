<!DOCTYPE html>

<html>
    <head>
        <title>Bootstrap</title>
        <meta name= "viewport" content="width =device-width, initial-scale= 1.0" >
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="css/styles.css" rel="stylesheet">
    </head>
    <body>
        <div class ="navbar navbar-inverse navbar-static-top">
           <div class ="container">
                
               <a href= "#" class="navbar-brand"> Blank </a>
                
               <button class="navbar-toggle" data-toggle="collapse" data-target =".navHeaderCollapse">
                   <span class ="icon-bar"></span>
                   <span class ="icon-bar"></span>
                   <span class ="icon-bar"></span>
               </button>
                
                  
                 <!--<div class="collapse navbar-collapse navHeaderCollapse">
               
                   <ul class ="nav navbar-nav navbar-right">
                   
                       <li class="active"><a href = "#">Home</a></li>
                       <li><a href = "#">Blog</a></li>
                       
                         <li class=dropdown">
                             <a href="#" class = "dropdown-toggle" data-toggle ="dropdown"> Social Media <b class="caret"></b></a>
                           
                            <ul class="dropdown-menu">
                               
                                <li><a href ="#">Facebook</a></li>
                                <li><a href ="#">Twitter</a></li>
                                <li><a href ="#">Instagram</a></li>
                                <li><a href ="#">Facebook</a></li>
                             </ul>
                       
                         </li>    
                       
                        <li><a href = "#">About</a></li>
                        <li><a href = "#">Contact</a></li>
                   
                   </ul>
               
                 </div>-->
                 
           </div> 
        </div>
        
        <div class="container">
            <p> Thank you for submitting your report. 
                Your report will be put into our database and we will display a marker to the location of the emergency.
                If you need police help, please call 999 for further assistance.
            </p>
            
            
            <a href="Home.php">Return to Homepage</a>
        </div>
        
        <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"> </script>
        <script src="js/bootstrap.js"></script>
    </body>
</html>
