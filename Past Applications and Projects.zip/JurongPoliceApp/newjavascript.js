<!DOCTYPE html>
<html>
<body>
<script>
var latarray = [];
var lonarray = [];
var idarray = [];
for (var i = 0; i <5; i++){
    latarray[i] = "#txtlatitude" + i;
    lonarray[i] = "#txtlongitude" + i;
    idarray[i] = i;
}
</script>
</body>
</html>