<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>handle horoscope</title>
        <style>
            body {
                
                font-family: "Trebuchet MS", "Helvetica", "Arial",  "Verdana", "sans-serif";
                font-size: 80%;
            }
        </style>
    </head>
    <body>
        <?php
            $birthday = $_POST["birthday"];
                 
            $month = (int) _________________(a)____________________;
            $day   = (int) _________________(b)____________________;
            
            

(c)


                       
            echo 'Your horoscope : <br /><br />' . $horoscope . '<br /><br />';
            echo '<img src="img/' . $horoscope . '.gif" ><br /><br />';
            echo 'Your characteristics : <br /><br />' . $characteristics . ' <br /><br />';
        ?>
        <a href="horoscopeForm.html">try again</a>
    </body>
