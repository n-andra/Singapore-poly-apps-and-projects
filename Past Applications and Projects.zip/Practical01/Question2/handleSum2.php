<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>handle sum</title>
        <style>
            body {
                text-align :center;
                font-family: monospace;
            }
        </style>
    </head>
    <body>
        <?php
           if(isset($_POST["value1"]) && isset($_POST["value2"])){
               
         
            $value1 = $_POST["value1"];
            $value2 = $_POST["value2"];
            $name = $_POST["op"];
            
            
           $sum = $value1 + $value2;
           $subtract = $value1 - $value2;
           $multiply = $value1 * $value2;
           $divide = $value1 / $value2;
           
               
           
           switch ($name){
               
               case "add" : // Checks $name variable if the value is "add"
                   echo $value1 . ' added by ' . $value2 . ' is ' . $sum; 
                  break;
               
               case "subtract" : // Checks $name variable if the value is "subtract"
                   echo $value1 . ' subtracted by ' . $value2 . ' is ' . $subtract;
                   break;
               
               case "multiply" : // Checks $name variable if the value is "multiply"
                   echo $value1 . ' multiplied by ' . $value2 . ' is ' . $multiply;
                   break;
               
               case "divide" : // Checks $name variable if the value is "divide"
                   echo $value1 . ' divided by ' . $value2 . ' is ' . $divide;
                   break;
           } 
               
         
           } else {
               echo "No values present <br />";
           } 
              
     
        ?>
        <a href="sumNumberForm2.html">do another calculation</a>
    </body>
</html>
