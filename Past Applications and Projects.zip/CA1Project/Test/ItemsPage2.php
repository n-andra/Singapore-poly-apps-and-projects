<html>
    <head> 
        <title>Bootstrap</title>
        <meta name= "viewport" content="width =device-width, initial-scale= 1.0" >
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="css/styles.css" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="css/CSS.css">
       
    </head><!-- this is the hrefs for the imported variables we use in the body -->
  
    <body>
        <div class ="navbar navbar-inverse navbar-static-top">
           <div class ="container">
                
                <a href= "#" class="navbar-brand"> Carlston's Wood Goods. "If it aint Wood, it aint good!"</a>
                
               <button class="navbar-toggle" data-toggle="collapse" data-target =".navHeaderCollapse">
                   <span class ="icon-bar"></span>
                   <span class ="icon-bar"></span>
                   <span class ="icon-bar"></span>
               </button>
               
                 <div class="collapse navbar-collapse navHeaderCollapse">
               
                   <ul class ="nav navbar-nav navbar-right">
                   
                       <li><a href = "About.php">About</a></li>
                       
                          <li class="dropdown active">
                            <a href="#" class = "dropdown-toggle" data-toggle ="dropdown"> Our Collection <b class="caret"></b></a>
                            <ul class="dropdown-menu">
                             <li><a href ="ItemsPage.php?type=Tables">Tables</a></li>
                             <li><a href ="ItemsPage.php?type=Lamps">Lamps</a></li>
                             <li><a href ="ItemsPage.php?type=Chairs">Chairs</a></li>
                            </ul>
                          </li>    
                       
                       
                        <li><a href = "#contact" data-toggle = "modal">Contact</a></li>
                   
                   </ul>
               
                 </div>
           </div> 
        </div> <!-- Header -->
        <?php 
     /*   
        include 'productArray.php';
        $product = $_GET['product'];
       for($i=0; $i<=1; $i++){ 
        if ($product == $tableArray[1][$i]){
       echo '<div class="container">';
       echo '<div class="row">';
        echo '<div class="col-lg-6">';
        echo '<div class="panel panel-default">';
        echo '<div class="panel-body">';
        echo '<div class="page-header">';
         echo '<img class="featureImg" src="$product"/>';                            
                             
                                
                                
                                
         echo '</div>';
        echo '</div>';
        echo '</div>';
        echo '</div>';
       echo '</div>';
       echo '<div class="col-lg-6">'; 
        echo '<div class="list-group">';
        echo '<div class="panel panel-default">';
        echo '<div class="panel-body">';
        echo '<div class="page-header">';
          echo "<h2>". $product ."</h2>";
      echo '</div>';         
      
      
      echo $tableArray[$i+1][$i];
        }
       } 
      */include 'productArray.php';
        $limit = 0;
        $type = $_GET["type"];
       $product = $_GET["product"];  
      if( $type == "Table" ){
      for($product; $product <= count($tableArray[1]); $product++){
       
      /*  $j = isset($_GET['product'])? $_GET['product'] : 0 ;
        $k = 0;*/
            $header = $tableArray[1][$product-1];
            $body = $tableArray[2][$product-1];
            $footer = $tableArray[3][$product-1];
            $desc = $tableArray[5][$product-1];
           $limit += 1;
      echo '<div class="container">';
       echo '<div class="row">';
        echo '<div class="col-lg-6">';
        echo '<div class="panel panel-default">';
        echo '<div class="panel-body">';
        echo '<div class="page-header">';
         echo '<img class="featureImg" src="$tableArray[0][$i]"/>';                            
                             
                                
                                
                                
         echo '</div>';
        echo '</div>';
        echo '</div>';
        echo '</div>';
         echo '<div class="col-lg-6">'; 
        echo '<div class="list-group">';
        echo '<div class="panel panel-default">';
        echo '<div class="panel-body">';
        echo '<div class="page-header">';
          echo "<h2>". $header ."</h2>";
       echo '</div>';
      
      echo '</div>';         
      
      
      echo "<p>" . $body . "</p>";
      echo '</br>';
      echo '<div class=panel>';
      echo $footer;
      echo '</br>';
      echo $desc;
       if ($limit != 0) {
                 break;
            }
           
                                    }
                       }
    elseif ($type == "Chair") {
        
    for($product; $product <= count($chairArray[1]); $product++){
       
      /*  $j = isset($_GET['product'])? $_GET['product'] : 0 ;
        $k = 0;*/
            $header = $chairArray[1][$product-1];
            $body = $chairArray[2][$product-1];
            $footer = $chairArray[3][$product-1];
            $desc = $chairArray[5][$product-1];
           $limit += 1;
      echo '<div class="container">';
       echo '<div class="row">';
        echo '<div class="col-lg-6">';
        echo '<div class="panel panel-default">';
        echo '<div class="panel-body">';
        echo '<div class="page-header">';
         echo '<img class="featureImg" src="$tableArray[0][$i]"/>';                            
                             
                                
                                
                                
         echo '</div>';
        echo '</div>';
        echo '</div>';
        echo '</div>';
         echo '<div class="col-lg-6">'; 
        echo '<div class="list-group">';
        echo '<div class="panel panel-default">';
        echo '<div class="panel-body">';
        echo '<div class="page-header">';
          echo "<h2>". $header ."</h2>";
       echo '</div>';
      
      echo '</div>';         
      
      
      echo "<p>" .$body . "</p>";
      echo '</br>';
      echo '<div class=panel>';
      echo $footer;
      echo '</br>';
      echo $desc;
       if ($limit != 0) {
                 break;
            }
    }
    }
elseif ($type=='Lamp'){ 
   for($product; $product <= count($lampArray[1]); $product++){
  
            $header = $lampArray[1][$product-1];
            $body = $lampArray[2][$product-1];
            $footer = $lampArray[3][$product-1];
            $desc = $lampArray[5][$product-1];
           $limit += 1;
      echo '<div class="container">';
       echo '<div class="row">';
        echo '<div class="col-lg-6">';
        echo '<div class="panel panel-default">';
        echo '<div class="panel-body">';
        echo '<div class="page-header">';
         echo '<img class="featureImg" src="$tableArray[0][$i]"/>';                            
                             
                                
                                
                                
         echo '</div>';
        echo '</div>';
        echo '</div>';
        echo '</div>';
         echo '<div class="col-lg-6">'; 
        echo '<div class="list-group">';
        echo '<div class="panel panel-default">';
        echo '<div class="panel-body">';
        echo '<div class="page-header">';
          echo "<h2>". $header ."</h2>";
       echo '</div>';
      
      echo '</div>';         
      
      
      echo "<p>" .$body . "</p>";
      echo '</br>';
      echo '<div class=panel>';
      echo $footer;
      echo '</br>';
      echo $desc;
       if ($limit != 0) {
                 break;
        }
    }
   }
  
       
     
     

        ?>     
        <div class="modal fade" id="contact" role="dialog" >
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4> Have an inquiry? Contact us!</h4>
                    </div>
                    <form action ="handleFeedback.php" method="post">
                      <div class="modal-body">
                          Name:<br/>
                          <input type ="text" name="username" /><br/>
                          Message : <br/>
                          <textarea name="msg" rows="4" cols="50"></textarea>
                      </div>
                      <div class="modal-footer">
                          <button class="btn btn-primary" type="submit"/>Send</button>
                          <button class="btn btn-warning" data-dismiss="modal">Close</button>
                      </div>
                    </form>   
                </div>  
                
            </div>    
            
        </div>
        
        
        <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"> </script>
        <script src="js/bootstrap.js"></script>
    </body>
</html>