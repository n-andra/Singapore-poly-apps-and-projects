<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>

    <head>
         <title>Carlston's</title>
       
        <meta name= "viewport" content="width =device-width, initial-scale= 1.0" >
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="css/styles.css" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="css/CSS.css">
    
        
    </head>
    <body>
      <div class ="navbar navbar-inverse navbar-static-top">
            <div class ="container">
               <a href= "Homepage.php" class="navbar-brand"> Carlston's Wood Goods. "If it aint Wood, it aint good!"</a>
                <button class="navbar-toggle" data-toggle="collapse" data-target =".navHeaderCollapse">
                   <span class ="icon-bar"></span>
                   <span class ="icon-bar"></span>
                   <span class ="icon-bar"></span>
                </button>
                <div class="collapse navbar-collapse navHeaderCollapse">
                    <ul class ="nav navbar-nav navbar-right">
                        <li class="active"><a href = "About.php">About</a></li>
                         <li class="dropdown">
                             <a href="OurCollection.php" class = "dropdown-toggle" data-toggle ="dropdown"> Our Collection <b class="caret"></b></a>
                            <ul class="dropdown-menu">
                             <li><a href ="ItemsPage.php?type=Tables">Tables</a></li>
                             <li><a href ="ItemsPage.php?type=Lamps">Lamps</a></li>
                             <li><a href ="ItemsPage.php?type=Chairs">Chairs</a></li>
                            </ul>
                         </li>
                        <li><a href = "#contact" data-toggle = "modal">Contact</a></li>
                    </ul>
                </div>
            </div> 
        </div> 
        <div class ="container">  
         <div class = "row">
          <div class="col-lg-8">             
            <div class ="panel panel-default">
             <div class="panel-body">
                <div class="page-header">   
                 <h3>Welcome to Carlston's!</h3>
                </div>
                 <img class ="featureImg" src = "img/Carlston.png" width=100>
                <p>Welcome to Carlston's. The furniture shop you can trust. We sell a wide range of
                furniture products ranging from Tables to Lamps to Chairs. You name it, we have it. 
                Only at Carlston's. Browse through our Featured Products or jump straight into
                our multitude of furniture fit for your home.</p>
             </div>
            </div>
          </div>
         
           
        
         <div class="col-lg-3">
            <div class="list-group">
              <h4 class="list-group-item active"> Featured Products </h4>
        <?php
       // include 'productArray.php';
         $con = new mysqli("localhost:3306", "waduser01", "st2220", "carlstondb");
         $result = mysqli_query($con, "SELECT * FROM admin");
            while ($row =  mysqli_fetch_array($result)){
                echo "ID No.: " .$row['id'] ."<br/>";
                echo "Username: " .$row['Username'] ."<br/>";
                echo "Password: " .$row['Password'] ."<br/>";
                echo "Name: " .$row['AdmName'] ."<br/>";
                   
             }
          
        
          /*      
         for ($i=0; $i<count($featuredProduct); $i++){
            $checker= explode(" ", $featuredProduct[$i][0]);
            echo "<a href="."ItemsPage2.php"."?type=".$checker[0]."&product=".$featuredProduct[$i][3]. " "."class=list-group-item".">";
            echo "<h4 class=list-group-item-heading>".$featuredProduct[$i][0]."</h4>";
            echo "<img class=featuredImg"." ". "src=".$featuredProduct[$i][2].">";
            echo "<p class=list-group-item-heading>".$featuredProduct[$i][1]."</p>";
            echo "</a>";             
         }
       */
        
        ?>
            </div>
         </div>
            
        <div class="modal fade" id="contact" role="dialog" >
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4> Have an inquiry? Contact us!</h4>
                    </div>
                    <form action ="handleFeedback.php" method="post">
                      <div class="modal-body">
                          Name:<br/>
                          <input type ="text" name="username" /> <br/>
                          Message : <br/>
                          <textarea name="msg" rows="4" cols="50"></textarea>
                      </div>
                      <div class="modal-footer">
                          <button class="btn btn-primary" type="submit"/>Send</button>
                          <button class="btn btn-warning" data-dismiss="modal">Close</button>
                      </div>
                    </form>   
                </div>  
                
            </div>    
            
        </div>
        
         </div>    
        </div>
        
        <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"> </script>
        <script src="js/bootstrap.js"></script>
    </body>
</html>
