<?php
$featuredProduct = array(array ("Table D",
                               "The best table out there, made purely out of 100% Oak Wood",
                               "img/img4.jpg",
                                "4"),
                         array ("Lamp A",
                                "The best Lamp in Singapore, named only because of how Super it is.",
                                "img/img11.jpg",
                                "1"),
                         array ("Chair B",
                                "The only chair found in Atlantis, a really rare find.",
                                "img/img22.jpg",
                                "2")
                        );
                            
$productsSold = array(array('Tables',
                            'Lamps',
                            'Chairs'),
                      array('Browse through some great quality tables',
                            'The best quality Lamps',
                            'The best chairs downtown'),
                            );
              //0           0    
 $tableArray =  array(array(          "img/img1.jpg", 
                                      "img/img2.jpg", 
                                      "img/img3.jpg", 
                                      "img/img4.jpg"),
              //           1     
                    array(        "Table A",
                                  "Table B", 
                                  "Table C",
                                  "Table D"),
              //           2
                    array(                "Maple Wood", 
                                          "Oak Wood", 
                                          "Yew Wood", 
                                          "Red Wood",
                                          ),
              //           3
                    array(           "$150", 
                                     "$250",
                                     "$350",
                                     "$120"),
                    array(           "1",
                                     "2",
                                     "3",
                                     "4"),
                    array(           "Made out of 100% Maple Wood imported from Canada and Constructed over at IKEA.",
                                     "Made out of 100% Oak Wood imported from Canada, handmade in Alaska.",
                                     "Made out of 100% Yew Wood imported from the USA, made with master craftsmen.",
                                     "Made out of 100% Red Wood from Australia, said to have been made by the aboriginals.")
                            );
 
 $lampArray = array(array("img/image11.jpg",
                          "img/image12.jpg",
                          "img/image13.jpg"
                          ),
                    array("Lamp A",
                          "Lamp B",
                          "Lamp C",
                          ),
                    array("Super Lamp",
                          "Mega Lamp",
                          "Ultra Lamp",
                          ),
                    array("$150", 
                          "$250",
                          "$350",
                          ),
                    array(           "1",
                                     "2",
                                     "3"),
                    array(           "Not made in China, made in IKEA.",
                                     "Designed by the best designers.",
                                     "Named aptly by it's creator, Ultraman.")
                    );

$chairArray = array(array("img/img21.jpg",
                          "img/img22.jpg",
                          "img/img23.jpg"
                          ),
                    array("Chair A",
                          "Chair B",
                          "Chair C"
                          ),
                    array("Best Chair",
                          "Really Good Chair",
                          "Supreme Chair"
                          ),
                    array("$150", 
                          "$250",
                          "$350",
                          ),
                    array(           "1",
                                     "2",
                                     "3"),
                    array(           "The best chair we managed to find and get from IKEA",
                                     "A really good chair found in the outskirts of Japan",
                                     "The supreme chair, crafted in England and named after her majesty.")
    );

?>



