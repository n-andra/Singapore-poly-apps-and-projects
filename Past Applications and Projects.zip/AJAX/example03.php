<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
        <script>
                    //For prev notes, check example02 of AJAX
            $(document).ready(function(){
                $("#yourInput").keyup(getTable);
            });
            
           function getTable(){
                var inputVal =  $("#yourInput").val();
                if (inputVal.trim().length != 0) {
                    var data = new Object();
                    data.userinput = inputVal;
                    $("#resultDIV").load("gentable.php", data, infoFadeIn);
                    //infoFadeIn happens after this line happens
                } else {
                    $("#resultDIV").html("");
                    $("#resultDIV").fadeOut();
                }
            }
                
           function infoFadeIn(responseTxt, statusTxt, xhr){
               if(statusTxt=="success" && responseTxt.trim().length !=0){
                 $("#resultDIV").fadeIn();
               } else{
                   
               } $("#resultDIV").fadeOut();
           };     

        </script>
    </head>
   
    <body>
     <input id="yourInput" type="text" size="3" /> times table
     <br><br>
     <div id="resultDIV" style="padding:5px;width:200px;display:none;background-color:lavender;"></div>
    </body>
</html>
