<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
        
        
        <script>    
        $(document).ready(function(){
                $("#yourInput").keyup(getTable);
                //getTable will run when you press and immediately lift up your finger from yourInput
                // Basically think of typing just ONE a (Dont hold it down), then an event happens
            });
            
            function getTable(){
               var inputVal = $("#yourInput").val();     
                 // Creates a new variable from the #'d
        
                 if(inputVal.trim().length !=0){ //trimming removes ALL spaces you put in the textbox
                  //if the length is not 0, when the var inputVal is trimmed...
                    var data = new Object();
                  //you create a new Object called data
                   data.userinput = inputVal;
                   //data is defined by the userinput, if the inputVal is not 0
                     $("#resultDIV").load("gentable.php", data);
                 } else{
                     $("#resultDIV").html("");
                    //alert("this is an empty space")
                    //
                 }
   
              //alert(' in getTable ' + inputVal);
            }

        </script>
        
    </head>
    <body>
        <input id="yourInput" type="text" size="3" /> times table
        <br /><br />
        <div id="resultDIV"></div>

    </body>
</html>
