<?php
    $num = $_POST['userinput'];

    for ($i=1; $i<=10; $i++) {
        echo $i . " X $num = " . ($i * $num) . "<br />";
    }
?>
