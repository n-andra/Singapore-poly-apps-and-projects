<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
    </head>
         <script>
             //document refers to THIS document, example01.php
            $(document).ready(function(){
                $("#button1").click(getImage);  
                //Click button 1, and the getImage function runs, this will run getImage.php
                
                $("#button2").click(getText);
                //Click button 2, and the getText function runs, this will run getText.php
                $("#button3").click(alert);
    });
            
            function getImage(){
             $("#resultDIV").load("getImage.php");
                       //  alert ("in getImage");
                       //Load the result of getImage into resutlDIV
            }
            
            function getText(){
             $("#resultDIV").load("getText.php");
                      // alert ("in getText");
                      //Load the result of getText into resutlDIV
            }
            
            function alert(){
             $("#resultDIV").ajaxSuccess(getText())
                 alert("Thank you for registering!");
             }
            
            
            
            
        </script>
        <body>
        <input id="button1" type="button" value="Get Image" />
        <input id="button2" type="button" value="Get Text" />
        <input id="button3" type="button" value="ALERT!" />
        <br /><br />
        <div id="resultDIV"></div>
    </body>
<?php
//no need for form, since it is all event driven using jquery
//jquery is the one handling all the work

?>
    
</html>
