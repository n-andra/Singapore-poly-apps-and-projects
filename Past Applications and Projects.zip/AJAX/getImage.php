<?php
    for ($i=1; $i<=10; $i++) {
        echo "<img src='Lolwailord.png' width ='20%' height='20%' >";
    }
?>
