<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<?php
if (isset($_POST["username"])){
    $expire = time()+60*60*24*30;
    setcookie("name", $_POST["username"], $expire);
    header ("Location: cookiesExample1.php");
} else if (isset($_GET["remove"])){
    setcookie("name", "", time()-3600);
    header ("Location: cookiesExample1.php");
    
}
?>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
       if (isset($_COOKIE["name"])){
           echo "Welcome back ". $_COOKIE["name"] . "<br/>";
           echo "<a href='cookiesExample1.php?remove=1'>Remove Me</a><br/>";
           
       } else {
           ?>
        <form action="cookiesExample1.php" method="post">
            Enter your name : <input type="text" name="username" /><br/>
            <input type="submit" value="submit"/>
        </form>
        
        <?php
       }
        ?>
    </body>
</html>
