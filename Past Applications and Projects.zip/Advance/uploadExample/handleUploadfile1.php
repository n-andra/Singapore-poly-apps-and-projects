<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        foreach($_FILES as $key => $fileInfoArr ){
            echo "Processing $key <br/>";
             if ($fileInfoArr["error"] > 0) {
               echo "Error: " . $fileInfoArr["error"] . "<br>";
                  } else {
                     echo "Upload: " . $fileInfoArr["name"] . "<br>";
                     echo "Type: " . $fileInfoArr["type"] . "<br>";
                     echo "Size: " . ($fileInfoArr["size"] / 1024) . " kB<br>";
                     echo "Stored in: " . $fileInfoArr["tmp_name"];
                  
                  if (file_exists($fileInfoArr["name"])) {
                      echo $fileInfoArr["name"] . " already exists.";
                  } else { 
                      move_uploaded_file($fileInfoArr["tmp_name"], $fileInfoArr["name"]);
                      echo "Stored in : " . $fileInfoArr["name"]; 
//  The above code is using the filename itself as file destination
                  }
                   
                     
                     
                     
                  }
                  echo "<br />";
        }
        /*
             if ($_FILES["myFile1"]["error"] > 0) {
               echo "Error: " . $_FILES["myFile1"]["error"] . "<br>";
                  } else {
                     echo "Upload: " . $_FILES["myFile1"]["name"] . "<br>";
                     echo "Type: " . $_FILES["myFile1"]["type"] . "<br>";
                     echo "Size: " . ($_FILES["myFile1"]["size"] / 1024) . " kB<br>";
                     echo "Stored in: " . $_FILES["myFile1"]["tmp_name"];
                  }
                  
                    if ($_FILES["myFile2"]["error"] > 0) {
               echo "Error: " . $_FILES["myFile2"]["error"] . "<br>";
                  } else {
                     echo "Upload: " . $_FILES["myFile2"]["name"] . "<br>";
                     echo "Type: " . $_FILES["myFile2"]["type"] . "<br>";
                     echo "Size: " . ($_FILES["myFile2"]["size"] / 1024) . " kB<br>";
                     echo "Stored in: " . $_FILES["myFile2"]["tmp_name"];
                  }
         
         */
?>

    </body>
</html>
