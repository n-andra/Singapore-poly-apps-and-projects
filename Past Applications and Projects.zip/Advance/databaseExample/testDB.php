<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        $con = mysqli_connect("localhost:3306", "jp2_testacct", "s9672252d", "testdatabase");
        
        //Check Connection
        if(mysqli_connect_errno($con)){
        echo "Failed to connect to MYSQL: " . mysqli_connect_error();
        } else {
            echo 'Success!<br/>';
            $result = mysqli_query($con, "INSERT INTO `testdatabase`.`account` (`ID`, `Name`, `Time`, `Date`, `Description`) VALUES (NULL, 'Robbery', '13:16', '2015-07-01', 'Robbery at Jurong Point')");
            
            if ($result->execute()){
                    echo "1 record added<br/>";
                    
                }
            mysqli_close($con);
        }
        
        ?>
    </body>
</html>