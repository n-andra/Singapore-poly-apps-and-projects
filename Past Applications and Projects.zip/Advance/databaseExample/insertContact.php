<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<?php
if (!isset($_POST['name']) || 
    !isset($_POST['email']) || 
    !isset($_POST['contact']))  {
    header("Location: exampleInsertForm.php?errorcode=1");
} else {
?>



<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        $conn = new mysqli("localhost:3306", "waduser01", "st2220", "myothercontactbook");
        
        if ($conn->connect_error){
            die("Connection failed: ". $conn->connect_error);
        } else{
                $sqlStr= "INSERT INTO friends ". 
                         "(name, email, contact)" . 
                         "VALUES(?, ?, ?)";
                
                $stmt = $conn->prepare($sqlStr);
                $stmt->bind_param("sss", $name, $email, $contact);
                
                $name    = $_POST['name'];
                $email   = $_POST['email'];
                $contact = $_POST['contact'];
                
                if ($stmt->execute()){
                    echo "1 record added<br/>";
                    echo "<a href='example02.php'>view records</a>";
                    
                } else {
                    echo "unsuccessful, please try again.<br/>";
                    echo "<a href='exampleInsertForm.php'>back</a>";
                }
                
            }
        /*
        $con = mysqli_connect("localhost:3306", "waduser01", "st2220", "myothercontactbook");
                
                if (mysqli_connect_errno($con)) {
                    echo "Failed to connect to MySQL: " . mysqli_connect_error();
                } else {
                    $sql = "INSERT INTO friends (name, email, contact)".
                           "VALUES ('$_POST[name]','$_POST[email]','$_POST[contact]')";
                    
                    if(!mysqli_query($con, $sql)) {
                        die('Error: '.mysqli_error($con));
                        
                    }
                    echo "1 record added<br/>";
                    echo "<a href='example02.php'>View Records</a>";
                    mysqli_close($con);
                } */
            
        ?>
    </body>
</html>
<?php
}

?>