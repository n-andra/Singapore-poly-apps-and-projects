<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
         $con = mysqli_connect("localhost:3306", "jp2_testacct", "s9672252d", "testdatabase");
        
        //Check Connection
        if(mysqli_connect_errno($con)){
        echo "Failed to connect to MYSQL: " . mysqli_connect_error();
        } else {
            echo 'Success!<br/>';
           $result = mysqli_query($con, "SELECT `Latitude`,`Longitude` FROM `Location` ORDER BY `ID` DESC LIMIT 1");
           
            while ($row =  mysqli_fetch_array($result)){
                echo"Record ID: " .$row['ID'] ."<br/>";
                echo"Latitude: " .$row['Latitude'] ."<br/>";
                echo"Longitude: ".$row['Longitude'];
                   
             }
            mysqli_close($con);
        }
        
        ?>
    </body>
</html>
