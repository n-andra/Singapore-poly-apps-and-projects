<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <form action="insertContact.php" method="post">
            Name : <input type="text" name="name"><br/>
            Email : <input type="text" name="email"><br/>
            Contact : <input type="text" name="contact"><br/>
            <input type="submit">
        </form>
    </body>
    
    <?php
     if(isset($_GET['errorcode'])){
               if($_GET['errorcode']==1){
                $msg = "Please Insert friends info here";
            } 
           
            echo "error $msg <br/>";
        }
    ?>
</html>
