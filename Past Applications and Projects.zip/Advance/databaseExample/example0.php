<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        $con = mysqli_connect("localhost:3306", "waduser01", "st2220", "myothercontactbook");
        
        //Check Connection
        if(mysqli_connect_errno($con)){
        echo "Failed to connect to MYSQL: " . mysqli_connect_error();
        } else {
            echo 'Success!';
            
            mysqli_close($con);
        }
        
        ?>
    </body>
</html>
