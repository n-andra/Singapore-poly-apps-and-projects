<?php
session_start();
$accountArr = ["tcs" => "123",
               "joe" => "hiiamjoe",
               "xyz" => "lolziz"];

if (isset($_POST["userid"]) && ($_POST["password"])){
    if(!isset($accountArr[$_POST['userid']])){
        header("Location: loginPage.php?errorcode=2");
    } else if ($accountArr[$_POST['userid']] !=$_POST['password']){
        header("Location: loginPage.php?errorcode=3");
    } else{ 
//        $_SESSION['user'] = $_POST['userid'];
        header("Location: welcome.php");
    }
} else {
    header("Location : loginPage.php?errorcode=1");
}
?>