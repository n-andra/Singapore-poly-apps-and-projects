<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<?php
session_start();
if (!isset($_SESSION['user'])){
    header ("Location: loginPage.php?errorcode=1");
}
?>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
       
        <h3>Welcome!</h3>
        <a href="handleLogout.php"> logout </a>
        <?php
        
        ?>
        
    </body>
</html>
