
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>



        <?php
        include './menuNavBar.php';
        require './myFunction.php';
        
        printPattern1(1);
        printPattern1(3);
        printPattern1(5);
        printPattern1(7);
        printPattern1(2);
       
        
        $row = isset($_GET['r']) ? $_GET['r'] : 5;

        for ($i = 0; $i <= $row; $i++) {
            print "hello $i <br/ >";
            echo 'hello $i <br />';
        }
        ?>


    </body>
</html>
