
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>

        <?php
         include './menuNavBar.php';
         
         require './myFunction.php';
          
          
        $name = isset($_GET['name']) ? $_GET['name'] : "Captain Falcon";
       
       
        
        echo 'the name is' . " " . $name . '<br />';
  
         
        $row = isset($_GET['r']) ? $_GET['r'] : 5;

        for ($i = 0; $i <= $row; $i++) {
            echo "hello $i <br />";
        }
       
        
        ?>


    </body>
</html>
