<?php

function printPattern1($size){
    
    for ($i=1; $i <=$size; $i++){
    echo "* ";
}
echo "<br/>";

}



function printPattern2 ($size){
    
    for ($r=1; $r<=$size; $r++){
        for ($c=1; $c<=$size; $c++){
            echo "* ";
             }

        echo "<br/>";
    }
    echo "<br/>";
}
?>