<html>
    <body>

<?php
   include './menuNavBar.php';
   require './myFunction.php';
   
   
$loop = isset($_GET['loop']) ? $_GET['loop']:0;
for ($r = 1; $r <= $loop;$r++){

for ($c = 1; $c <= $r ; $c++) {
echo "*";}
echo "<br/>";}

$loop = ++$loop%10;

echo "<a href = 'example03.php?loop=$loop'> NEXT </a>";

?>

     </body>
</html>


