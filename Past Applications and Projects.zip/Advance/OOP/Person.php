<?php

class Person {
 
    private $recordid;
    private $name;
    private $email;
    private $contact;
    
    function __construct($recordid, $name, $email, $contact) {
        $this ->recordid = $recordid;
        $this ->name = $name;
        $this->email = $email;
        $this->contact = $contact;
    }
    function PrintDetail(){
        echo "Record ID : $this->recordid <br/>" ;
        echo "Name : $this->name <br/>" ;
        echo "Email : $this->email <br/>" ;
        echo "Contact : $this->contact <br/>" ;
        
        
        
    }
}


?>