<?php

function getDbConnectObj(){
$conn = new mysqli("localhost:3306", "waduser01", "st2220", "myothercontactbook");
return $conn;
}
?>

