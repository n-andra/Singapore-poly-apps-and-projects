<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        
        <?php
       require_once './Person.php';
       require_once './DBFunction.php';
       require_once './DBPerson.php';
       
       $conn = getDbConnectObj();
       $friendsArr = getSearchPersonConn($conn);
       
       foreach ($friendsArr as $friend) {
           $friend->PrintDetail();
       }
       
       
       /* This stuff below works
        $p1 = new Person(1,"Joe" , "joe@sp.edu.sg", "123456");
        $p2 = new Person(2,"Liban" ,"liban@sp.com", "133722");
        
        $p1->PrintDetail();
        $p2->PrintDetail();
        */
?>
        
    </body>
</html>
