<?php

function getSearchPersonConn($conn){
    $result = array();
    
    if(!$conn->connect_error){
        $sqlStr= "SELECT F.recordid, F.name, F.email, F.contact " . 
                 "FROM friends F WHERE F.name Like ?"; //? is a variable you insert in
        //If there is an error here
        $stmt = $conn->prepare($sqlStr);
        $stmt-> bind_param("s",$searchStr);
        $stmt->execute();
        $stmt->bind_result($recid, $name, $email, $contact);
        while ($stmt->fetch()){
            $result[] = new Person($recid, $name, $email, $contact);
        }
        $stmt->close();
        
    }
    return $result;
    
}

?>

