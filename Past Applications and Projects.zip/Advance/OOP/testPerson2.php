<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
        <script>
            
    
    
    //For prev notes, check example02 of AJAX
            $(document).ready(function(){
                $("#searchInput").keyup(getFriends);
            });
            
         function getFriends(){
             var inputVal = $("#searchInput").val(); 
             
             if (inputVal.trim().length !=0){//means something is detected
             var data = new Object();
             data.searchStr = inputVal;
             $("#resultDIV").load("searchPerson.php", data);
         } else {
             $("#resultDIV").html("");
         }   
     }
            
            
        </script>
    </head>    
    <body>
    
        Search For: <input id="searchInput" type="text" size="30"/>
        <br /><br />
        <div id="resultDIV"></div>
    </body>
</html>
