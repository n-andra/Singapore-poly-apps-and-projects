<?php
require_once './DBFunction.php';
require_once './Person.php';
require_once './DBPerson.php';

$searchStr = "%". $_POST["searchStr"] . "%";
$conn = getDbConnectObj();
$friendsArr = getSearchPersonConn($conn, $searchStr);

if(!empty($friendsArr)) {
    foreach ($friendsArr as $friend) {
        $friend ->PrintDetail();
    }
} else {
   "No result found";
}


?>
