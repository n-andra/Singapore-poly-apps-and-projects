<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
       
        $name = $_POST['username'];
        $message = $_POST['msg'];
        
        //open a file for writing
        $outfile = fopen("feedback.txt", "a") or exit ("Unable to open file!");
        // write the content to the file
        fwrite($outfile, "hi cher, how's life\r\n");
        fwrite($outfile, "Name : $name\r\n");
        fwrite($outfile, "Message : \r\n$message\r\n");
        
        //if you use append, the cursor will start at the very end of the fwrite code
        
        // close the file
        fclose($outfile);
        
        ?>
        <h3> Done! </h3>
        <a href="feedback.html"> BACK </a>
    </body>
</html>
