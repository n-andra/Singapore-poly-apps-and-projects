<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        $infile = fopen("studentData.dat", "r") or exit("Unable to open file!");
        
        while (!feof($infile)){
            echo fgets($infile). "<br>"; // fgets checks for the next line in the file, and gets it
                                         // If there is, it gets and uploads the file into php
                                         // If not, we exit this loop and stop
            
            $inStr = fgets($infile);
            
            $infoArr = explode(" | ", $inStr);
            
            echo "<p>";
            echo "Admin No : " . $infoArr[0];
            echo "Name : " . $infoArr[1];
            echo "Email : " . $infoArr[2];
            echo "</p>"; 
             
        }
        fclose($infile);
        
        ?>
    </body>
</html>
