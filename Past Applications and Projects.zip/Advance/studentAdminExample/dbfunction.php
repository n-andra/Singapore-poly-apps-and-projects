<?php

function getDbConnect() {
    // get a database connect to studentacad database
    $con = mysqli_connect("localhost:3306", "waduser01", "st2220" , "studentacad");
    return $con;
}
    /*
    $c =  getDbConnect();
if (mysqli_connect_errno($c)){
    echo "Error";
    
} else {
    echo "OK!";
}
     */
     
?>
