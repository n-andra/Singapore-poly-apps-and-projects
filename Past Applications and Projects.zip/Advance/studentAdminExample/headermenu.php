<?php
echo "<h2>welcome back: " . $basicinfo['name'] . "</h2><br />";
?>
[<a href='homepage.php'>Home</a>] 
[<a href='viewbasicinfo.php'>view detail</a>] 
[<a href='handleLogout.php'>logout</a>] 
<br /><br />
