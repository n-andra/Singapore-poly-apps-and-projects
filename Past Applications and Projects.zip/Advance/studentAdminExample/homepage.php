<?php
// require the checkLoginStatus.php file
require_once './checkLoginStatus.php';

?>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        // include the headermenu.php  
        include './headermenu.php';
        ?>
        <br/>
        Welcome to the homepage!
    </body>
</html>
