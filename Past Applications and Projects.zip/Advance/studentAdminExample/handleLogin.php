<?php

// start a session
session_start();

// require the dbfunction.php file
require './dbfunction.php';


$adminid  = $_POST['adminid']; // retrieve the adminid from login form
$password = $_POST['password']; // retrieve the password from login form

$con = getDbConnect(); // invoke the getDbConnect() function to get a database connection

if (!mysqli_connect_errno($con)) { // connection to database is successful
    $sqlQueryStr =
            "SELECT BI.recordid, BI.adminid, BI.name, BI.class, BI.email, BI.contact " .
            "FROM account AC, basicinfo BI " .
            "WHERE AC.recordid = BI.recordid AND " .
            "BI.adminid = '$adminid' AND " .
            "AC.password = AES_ENCRYPT('$password','st2220')";

    $result = mysqli_query ($con, $sqlQueryStr); // execute the SQL query
    if($row = mysqli_fetch_array($result)) { // fetch the record
        $_SESSION['basicinfo'] = $row; // put the record into the session
         echo "in if<br/>";
         header('Location: homepage.php'); // redirect to the homepage.
    } else {
        echo "in else<br/>";
        header('Location: loginPage.html'); // redirect to the login page.
    }
    mysqli_close($con); // close database connection
} else {
    echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
?>
