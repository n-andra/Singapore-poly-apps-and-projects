<?php
// require the checkLoginStatus.php file
require_once './checkLoginStatus.php'

?>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        // include the headermenu.php  
        include './headermenu.php';
        ?>


        <h3>Personal Details:</h3>
        
        <?php

        //display information from basicinfo
        echo "record ID: " . $basicinfo['recordid']. "<br />";
        echo "name: "      . $basicinfo['name'] . "<br />";
        echo "class: "     . $basicinfo['currentclass'] . "<br />";
        echo "email: "     . $basicinfo['email'] . "<br />";
        echo "contact: "   . $basicinfo['contact'] . "<br />";
        echo "<br>";
        ?>
        
    </body>
</html>
