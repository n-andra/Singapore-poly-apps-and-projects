<?php
// start a session
session_start();

if (isset ($_SESSION['basicinfo'])) { // basicinfo exist in session
    $basicinfo = $row['basicinfo']; // get basicinfo from session
} else {
    header('Location: LoginPage.html'); // redirect to the login page.
}
?>

