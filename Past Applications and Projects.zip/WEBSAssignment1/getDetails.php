<html>
    <head></head>
    <body>
<?php
 $r = new HttpRequest('http://api.worldweatheronline.com/free/v2/weather.ashx?q=china&format=xml&num_of_days=5&key=6f3167b4e4b3e38b6de7a8895b119', 
HttpRequest::METH_GET); 

?>
    </body>
    
</html>
