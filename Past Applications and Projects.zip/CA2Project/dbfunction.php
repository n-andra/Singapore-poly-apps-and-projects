<?php
function getDBConnect(){ 
   $con = mysqli_connect("localhost", "waduser01", "", "p1315787db2");
    return $con;
}
