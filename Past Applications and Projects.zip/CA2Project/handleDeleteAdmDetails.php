<html>
    <head> 
        <title>Bootstrap</title>
        <meta name= "viewport" content="width =device-width, initial-scale= 1.0" >
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="css/styles.css" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="css/CSS.css">
       
    </head><!-- this is the hrefs for the imported variables we use in the body -->
    <body>
        <div class ="navbar navbar-inverse navbar-static-top">
            <div class ="container">
               <a href= "Homepage.php" class="navbar-brand dropdown-toggle" data-toggle ="dropdown"> Carlston's Wood Goods. "If it aint Wood, it aint good!"</a>             
               <button class="navbar-toggle" data-toggle="collapse" data-target =".navHeaderCollapse">
                   <span class ="icon-bar"></span>
                   <span class ="icon-bar"></span>
                   <span class ="icon-bar"></span>
                </button>
                <div class="collapse navbar-collapse navHeaderCollapse">
                    <ul class ="nav navbar-nav navbar-right">
                        <li class="active"><a href = "About.php">About</a></li>
                         <li class="dropdown">
                             <a href="OurCollection.php" class = "dropdown-toggle" data-toggle ="dropdown"> Our Collection <b class="caret"></b></a>
                            <ul class="dropdown-menu"> <?php
            $con = mysqli_connect("localhost:3306", "waduser01", "st2220", "p1315787db");
            $catquery = mysqli_query($con, "SELECT * FROM category");
             while ($row = mysqli_fetch_array($catquery)){
                 echo "<li><a href="."ItemsPage.php?catID=".$row["catID"].">".$row["catName"]."</a></li>";
             }
             
                             ?>
                             <li><a href="OurCollection.php">Collection</a></li>
                            </ul>
                            
                         </li>
                        <li><a href = "#contact" data-toggle = "modal">Contact</a></li>
                    </ul>
                </div>
            </div> 
        </div> 
        <div class="container">
        <h3>Delete Admin</h3>   
        <?php
        
       $con = mysqli_connect("localhost:3306", "waduser01", "st2220", "p1315787db");
        $admID   = $_POST['id'];
        $admName = $_POST['adname'];
        //$recordDelete = mysqli_query($con, "DELETE FROM featured WHERE recordid = $recordid");
           /* while ($row = mysqli_fetch_array($recordRetrv)){
                $catName = $row['catName'];
               
            * 
            }        */
            
        if (!mysqli_connect_errno($con)) { // connection to database is successful
           $sqlQueryStr =
                   "DELETE FROM admin WHERE AdmName = "."'".$admName."'". " AND id = ".$admID;


               
               mysqli_query($con, $sqlQueryStr);
               echo "Admin Removed";
               mysqli_close($con);
       } else {
           echo "Failed to connect to MySQL: " . mysqli_connect_error();
       }
       ?>
        </div>
    </body>
</html>