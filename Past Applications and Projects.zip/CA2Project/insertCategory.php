<?php

?>
<!DOCTYPE html>

<html>
    <head> 
        <title>Bootstrap</title>
        <meta name= "viewport" content="width =device-width, initial-scale= 1.0" >
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="css/styles.css" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="css/CSS.css">
       
    </head><!-- this is the hrefs for the imported variables we use in the body -->
    <body>
        <div class ="navbar navbar-inverse navbar-static-top">
            <div class ="container">
               <a href= "Homepage.php" class="navbar-brand dropdown-toggle" data-toggle ="dropdown"> Carlston's Wood Goods. "If it aint Wood, it aint good!"</a>             
               <button class="navbar-toggle" data-toggle="collapse" data-target =".navHeaderCollapse">
                   <span class ="icon-bar"></span>
                   <span class ="icon-bar"></span>
                   <span class ="icon-bar"></span>
                </button>
                <div class="collapse navbar-collapse navHeaderCollapse">
                    <ul class ="nav navbar-nav navbar-right">
                        <li class="active"><a href = "About.php">About</a></li>
                         <li class="dropdown">
                             <a href="OurCollection.php" class = "dropdown-toggle" data-toggle ="dropdown"> Our Collection <b class="caret"></b></a>
                            <ul class="dropdown-menu">  <?php
        $con = mysqli_connect("localhost:3306", "waduser01", "st2220", "p1315787db");
            $catquery = mysqli_query($con, "SELECT * FROM category");
             while ($row = mysqli_fetch_array($catquery)){
                 echo "<li><a href="."ItemsPage.php?catID=".$row["catID"].">".$row["catName"]."</a></li>";
             }?>
                             <li><a href="OurCollection.php">Collection</a></li>
                            </ul>
                            
                         </li>
                        <li><a href = "#contact" data-toggle = "modal">Contact</a></li>
                    </ul>
                </div>
            </div> 
        </div> 
        
           <div class ="container">
        <h3>Add New Category</h3>
        <form action="handleInsertCategory.php" method="post">
        <table>
            <tr>
                <td>Category ID</td>
                <td>: <input type="text" name="catID" size="50"/></td>    
            </tr>
            <tr>
                <td>Category Name</td>
                <td>: <input type="text" name="catName"size="50"/></td>    
            </tr>
            <tr>
                <td>Upload Image File :</td>
                <td><?php
                            if(isset($_POST['submit'])){
                      $name = $_FILES["file"]["name"];
                      $size = $_FILES['file']['size'];
                      $type = $_FILES['file']['type'];
                      $extension=  strtolower(substr($name,strpos($name,'.')+1));
                      $max_size=2097152;

                      $tmp_name = $_FILES['file']['tmp_name'];
                      $error = $_FILES['file']['error'];

                      if (isset ($name)) {
                          if (!empty($name)) {
                           if(($extension=='jpg'||$extension=='jpeg')&&$type=='image/jpeg'&&$size<=$max_size){
                             $location = 'uploads/';  
                             if  (move_uploaded_file($tmp_name, $location.$name)){
                              echo 'Uploaded';    
                              }else{
                                  echo"there was an error";
                              }
                           }
                           else{
                               echo"file is too small/big";
                           }
                              }


                          }
                          else {
                                echo 'please choose a file';
                                }
                      }
                ?>
                    <form action="" method="POST" enctype="multipart/form-data">
    <input type="file" name="file">
    </td>
<!--    <input type="submit" name="submit" value="Submit"></td>    -->
            </tr>
            <tr>
                <td>&nbsp;</td>
                <td align="right"><input type="submit" name="submit" value="Add"/></td>
                
            </tr>
        </table>
           </div>
        </form>
    </body>
</html>
