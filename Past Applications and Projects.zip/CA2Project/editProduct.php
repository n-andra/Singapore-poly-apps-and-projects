<?php
session_start();
?>
<!DOCTYPE html>

<html>
    <head> 
        <title>Bootstrap</title>
        <meta name= "viewport" content="width =device-width, initial-scale= 1.0" >
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="css/styles.css" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="css/CSS.css">
        
        
       
    </head><!-- this is the hrefs for the imported variables we use in the body -->
    <body>
        <div class ="navbar navbar-inverse navbar-static-top">
            <div class ="container">
               <a href= "Homepage.php" class="navbar-brand dropdown-toggle" data-toggle ="dropdown"> Carlston's Wood Goods. "If it aint Wood, it aint good!"</a>             
               <button class="navbar-toggle" data-toggle="collapse" data-target =".navHeaderCollapse">
                   <span class ="icon-bar"></span>
                   <span class ="icon-bar"></span>
                   <span class ="icon-bar"></span>
                </button>
                <div class="collapse navbar-collapse navHeaderCollapse">
                    <ul class ="nav navbar-nav navbar-right">
                        <li class="active"><a href = "About.php">About</a></li>
                         <li class="dropdown">
                             <a href="OurCollection.php" class = "dropdown-toggle" data-toggle ="dropdown"> Our Collection <b class="caret"></b></a>
         <ul class="dropdown-menu">  <?php
          $con = mysqli_connect("localhost:3306", "waduser01", "st2220", "p1315787db");
            $catquery = mysqli_query($con, "SELECT * FROM category");
             while ($row = mysqli_fetch_array($catquery)){
             echo "<li><a href="."ItemsPage.php?catID=".$row["catID"].">".$row["catName"]."</a></li>";
             }?>
                             <li><a href="OurCollection.php">Collection</a></li>
                            </ul>
                            
                         </li>
                        <li><a href = "#contact" data-toggle = "modal">Contact</a></li>
                    </ul>
                </div>
            </div> 
        </div> 
        
        <div class ="container">
        <h3>Edit Product</h3>
        <form action="handleEditProduct.php" method="post">
        <table>
            <?php 
            
            
        $recordID = isset($_GET['recordid'])? $_GET['recordid'] : 'none';
        $catID = isset($_GET['catID'])? $_GET['catID'] : 'none';
     $con = mysqli_connect("localhost:3306", "waduser01", "st2220", "p1315787db");
        $catRetrieve = mysqli_query($con, "SELECT catID FROM category WHERE catID = $catID");
        while ($row = mysqli_fetch_array($catRetrieve)){
            $catIdentifier = $row['catID'];
        }
        if ($catID = $catIdentifier){
            $catNameGet = mysqli_query($con, "SELECT catName FROM category WHERE catID = $catID");
            while ($row = mysqli_fetch_array($catNameGet)){
                $catName = $row['catName'];
               
            }        
        }
     /*  $catNameRetr = mysqli_query($con, "SELECT category.catName FROM category "
                         . "INNER JOIN (lamps, tables, chairs) "
                         . "ON (lamps.catID = category.$catID "
                         . "OR tables.catID = category.$catID "
                         . "OR chairs.catID = category.$catID)");
      * 
      
       while($row=  mysqli_fetch_array($catNameRetr)){
           echo $row['catName'];
           $table = 0;
       }
       */
        $DsplyDetails = mysqli_query($con, "SELECT * FROM $catName "." WHERE (recordid = $recordID AND catID = $catID) ");
       
          while ($row = mysqli_fetch_array($DsplyDetails)){
              echo '<table>';
              echo '<tr>';
              echo '<td>Product ID</td>';
              echo '<td>: <input type="text"  name="recordid"  size="50" value="'.$row['recordid'].'"/></td>';
              echo '</tr>';
              
              echo '<tr>';
              echo '<td>Product Name</td>';
              echo '<td>: <input type="text"  name="productName"  size="50" value="'.$row['Name'].'"/></td>';
              echo '</tr>';
              
              echo '<tr>';
              echo '<td>Category ID</td>';
              echo '<td>: <input type="text"  name="catID" size="50" value="'.$row['catID'].'"/></td>';    
              echo '</tr>';
              
              echo '<tr>';
              echo '<td>Product Description 1</td>';
              echo '<td>: <input type="text"  name="Description" size="50" value="'.$row['Description1'].'"/></td>';
              echo '</tr>';
              
              echo '<tr>';
              echo '<td>Product Description 2</td>';
              echo '<td>: <input type="text"  name="Description2" size="50" value="'.$row['Description2'].'"/></td>'; 
              echo '</tr>';
              
              echo '<tr>';
              echo '<td>Price</td>';
              echo '<td>: <input type="text"  name="price" size="50" value="'.$row['Price'].'"/></td>'; 
              echo '</tr>';
              
              echo '<tr>';
              echo '<td>Image File</td>';
              echo '<td>: <input type="text"  name="Image" size="50" value="'.$row['Image'].'"/></td>';
              echo '</tr>';
              echo '</table>';
              echo '<br/>';
          }
        
                            if(isset($_POST['submit'])){
                      $name = $_FILES["file"]["name"];
                      $size = $_FILES['file']['size'];
                      $type = $_FILES['file']['type'];
                      $extension=  strtolower(substr($name,strpos($name,'.')+1));
                      $max_size=2097152;

                      $tmp_name = $_FILES['file']['tmp_name'];
                      $error = $_FILES['file']['error'];

                      if (isset ($name)) {
                          if (!empty($name)) {
                           if(($extension=='jpg'||$extension=='jpeg')&&$type=='image/jpeg'&&$size<=$max_size){
                             $location = 'uploads/';  
                             if  (move_uploaded_file($tmp_name, $location.$name)){
                              echo 'Uploaded';    
                              }else{
                                  echo"there was an error";
                              }
                           }
                           else{
                               echo"file is too small/big";
                           }
                              }


                          }
                          else {
                                echo 'please choose a file';
                                }
                      }
                ?>
            
    <form action="" method="POST" enctype="multipart/form-data">
    <input type="file" name="file">
<!--    <input type="submit" name="submit" value="Submit"></td>    -->
        
            </tr>
            <tr>
                <td>&nbsp;</td>
                <td align="right"><input type="submit" name="submit" value="Edit"/></td>
                
            </tr>
        </table>
           </div>
        </form>
    </body>
</html>
