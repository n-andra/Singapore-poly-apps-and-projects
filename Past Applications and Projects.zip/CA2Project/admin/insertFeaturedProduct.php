<?php


?>
<!DOCTYPE html>
<html>
    <head>
        <title>Add Featured Product</title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    </head>
    <body>
        <?php
        
        // include the adminHeadermenu.php  
        include './adminHeadermenu.php';
        ?>
        
        <h3>Add Featured Product</h3>
        <form action="handleInsertStudentRequest.php" method="post">
        <table>
            <tr>
                <td>Category Code</td>
                <td>: <input type="text" name="Category Code" size="50"/></td>    
            </tr>
            <tr>
                <td>Title</td>
                <td>: <input type="text" name="Title"size="50"/></td>    
            </tr>
            <tr>
                <td>Description</td>
                <td>: <input type="text" name="currentclass" size="50" /></td>    
            </tr>
            <tr>
                <td>Upload Image File</td>
                <td>:
                             <?php
                            if(isset($_POST['submit'])){
                      $name = $_FILES["file"]["name"];
                      $size = $_FILES['file']['size'];
                      $type = $_FILES['file']['type'];
                      $extension=  strtolower(substr($name,strpos($name,'.')+1));
                      $max_size=2097152;

                      $tmp_name = $_FILES['file']['tmp_name'];
                      $error = $_FILES['file']['error'];

                      if (isset ($name)) {
                          if (!empty($name)) {
                           if(($extension=='jpg'||$extension=='jpeg')&&$type=='image/jpeg'&&$size<=$max_size){
                             $location = 'uploads/';  
                             if  (move_uploaded_file($tmp_name, $location.$name)){
                              echo 'Uploaded';    
                              }else{
                                  echo"there was an error";
                              }
                           }
                           else{
                               echo"file is too small/big";
                           }
                              }


                          }
                          else {
                                echo 'please choose a file';
                                }
                      }
                ?>
                    <form action="" method="POST" enctype="multipart/form-data">
    <input type="file" name="file"><br><br>
    </td>
<!--    <input type="submit" name="submit" value="Submit"></td>    -->
            </tr>
            <tr>
                <td>&nbsp;</td>
                <td align="right"><input type="submit" name="submit" value="Add"/></td>    
            </tr>
        </table>
        </form>
    </body>
</html>
