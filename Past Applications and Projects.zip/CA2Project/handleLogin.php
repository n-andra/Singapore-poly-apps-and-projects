<?php
session_start();
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
$con = mysqli_connect("localhost", "waduser02", "s9672252d", "p1315787db2");
$username = $_POST['username'];
$password = $_POST['password'];
echo $username;
echo $password;

/*if (mysqli_connect_errno($con)) {
    echo "Failed to connect to database: " . mysqli_connect_error($con);
} else {
    $query = mysqli_query($con, "SELECT Username,Password, AdmName "
                              . "FROM `admin` "
                              . "WHERE `Username` ='$username' "
                              . "AND `Password` = AES_ENCRYPT('$password','st2220')");
    $query2 = mysqli_query ($con, "SELECT CAST(AES_DECRYPT(AES_ENCRYPT('$password','st2220'),'st2220') AS CHAR) AS Password");
    echo $query;
    echo $query2;
    while ($row1 = mysqli_fetch_array($query2)){
        $pwcheck = $row1['Password'];
    }
    while ($row = mysqli_fetch_array($query)) {

        $namecheck = $row['Username'];
        $admNameGet = $row['AdmName'];
    
     if ($namecheck == $username && $pwcheck == $password) {
        $_SESSION['admin'] = $admNameGet;
        echo $_SESSION['admin'];
        mysqli_close($con);
        header('location:/About.php');
    } else {
        mysqli_close($con);
        header('location:/loginPage.php');
    }
   }
     
}
?>

 */