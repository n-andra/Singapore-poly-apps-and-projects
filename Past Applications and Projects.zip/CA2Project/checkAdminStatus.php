<?php
// start a session
session_start();

if (isset($_SESSION['user'])) {     // admininfo exist in session
    $admininfo = $_SESSION['user']; // get admininfo from session
} else {
    header('Location: loginPage.php');  // redirect to the login page.
} 
?>
