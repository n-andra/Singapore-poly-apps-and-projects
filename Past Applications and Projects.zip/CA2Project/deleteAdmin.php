<?php
session_start();
?>
<html>
    <head> 
        <title>Bootstrap</title>
        <meta name= "viewport" content="width =device-width, initial-scale= 1.0" >
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="css/styles.css" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="css/CSS.css">
       
    </head><!-- this is the hrefs for the imported variables we use in the body -->
    <body>
        <div class ="navbar navbar-inverse navbar-static-top">
            <div class ="container">
               <a href= "Homepage.php" class="navbar-brand dropdown-toggle" data-toggle ="dropdown"> Carlston's Wood Goods. "If it aint Wood, it aint good!"</a>             
               <button class="navbar-toggle" data-toggle="collapse" data-target =".navHeaderCollapse">
                   <span class ="icon-bar"></span>
                   <span class ="icon-bar"></span>
                   <span class ="icon-bar"></span>
                </button>
                <div class="collapse navbar-collapse navHeaderCollapse">
                    <ul class ="nav navbar-nav navbar-right">
                        <li class="active"><a href = "About.php">About</a></li>
                         <li class="dropdown">
                             <a href="OurCollection.php" class = "dropdown-toggle" data-toggle ="dropdown"> Our Collection <b class="caret"></b></a>
                            <ul class="dropdown-menu"> <?php
          $con = mysqli_connect("localhost:3306", "waduser01", "st2220", "p1315787db");
            $catquery = mysqli_query($con, "SELECT * FROM category");
             while ($row = mysqli_fetch_array($catquery)){
             echo "<li><a href="."ItemsPage.php?catID=".$row["catID"].">".$row["catName"]."</a></li>";
             }?>
                             <li><a href="OurCollection.php">Collection</a></li>
                            </ul>
                            
                         </li> 
                        <li><a href = "#contact" data-toggle = "modal">Contact</a></li>
                    </ul>
                </div>
            </div> 
        </div> 
        <?php
        /*
         $con = mysqli_connect("localhost:3306", "waduser01", "st2220", "carlstondb");
            $adminInfoGet= "SELECT * FROM admin";
         $adminQuery = mysqli_query($con, $adminInfoGet);
         while ($row = mysqli_fetch_array($adminQuery)){
              echo '<table>';
              echo '<tr>';
              echo '<td>Admin ID</td>';
              echo '<td>: <input type="text"  name="id"  size="50" value="'.$row['id'].'"/></td>';
              echo '</tr>';
              
              echo '<tr>';
              echo '<td>Username</td>';
              echo '<td>: <input type="text"  name="username"  size="50" value="'.$row['Username'].'"/></td>';
              echo '</tr>';
              
              echo '<tr>';
              echo '<td>Password</td>';
              echo '<td>: <input type="text"  name="password"  size="50" value="'.$row['Password'].'"/></td>';
              echo '</tr>';
              
              echo '<tr>';
              echo '<td>Admin Name</td>';
              echo '<td>: <input type="text"  name="adname"  size="50" value="'.$row['AdmName'].'"/></td>';
              echo '</tr>';
              
              echo '<tr>';
              echo '<td>&nbsp;</td>';
              echo '<td align="right"><input type="submit" name="submit" value="Edit"/></td>';
              echo '</tr>';
              echo '</table>';
         }
            
       ?>
    </body>
   </form>
</html>
         * *
         */
        ?>
<div class ="container">
        <form action="handleDeleteAdmDetails.php" method="post">
            
        <h3>Delete Admin</h3> 
        <table>
            <?php 
            
         $adminInfoGet= "SELECT * FROM `admin` WHERE `AdmName` NOT LIKE ". "'".$_SESSION['admin']."'";
         $adminQuery = mysqli_query($con, $adminInfoGet);
         while ($row = mysqli_fetch_array($adminQuery)){
              echo '<table>';
              echo '<tr>';
              echo '<td>Admin ID</td>';
              echo '<td>: <input type="text"  name="id"  size="50" value="'.$row['id'].'"/></td>';
              echo '</tr>';
              
              echo '<tr>';
              echo '<td>Admin Name</td>';
              echo '<td>: <input type="text"  name="adname"  size="50" value="'.$row['AdmName'].'"/></td>';
              echo '</tr>';
              
           echo '<tr>';
           echo '<td>&nbsp;</td>';
           echo '<td align="right"><input type="submit" name="submit" value="Delete"/></td>';
           echo'</tr>';
         }
        ?>

        </table>
           </div>
        </form>
    </body>
</html>