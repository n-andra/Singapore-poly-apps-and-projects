
<!DOCTYPE html>
<html>
    <head> 
        <title>Bootstrap</title>
        <meta name= "viewport" content="width =device-width, initial-scale= 1.0" >
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="css/styles.css" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="css/CSS.css">
       
    </head><!-- this is the hrefs for the imported variables we use in the body -->
    <body>
        <div class ="navbar navbar-inverse navbar-static-top">
            <div class ="container">
               <a href= "Homepage.php" class="navbar-brand dropdown-toggle" data-toggle ="dropdown"> Carlston's Wood Goods. "If it aint Wood, it aint good!"</a>             
               <button class="navbar-toggle" data-toggle="collapse" data-target =".navHeaderCollapse">
                   <span class ="icon-bar"></span>
                   <span class ="icon-bar"></span>
                   <span class ="icon-bar"></span>
                </button>
                <div class="collapse navbar-collapse navHeaderCollapse">
                    <ul class ="nav navbar-nav navbar-right">
                        <li class="active"><a href = "About.php">About</a></li>
                         <li class="dropdown">
                             <a href="OurCollection.php" class = "dropdown-toggle" data-toggle ="dropdown"> Our Collection <b class="caret"></b></a>
                            <ul class="dropdown-menu">
                                <?php
         $con = mysqli_connect("localhost:3306", "waduser01", "st2220", "p1315787db");
            $catquery = mysqli_query($con, "SELECT * FROM category");
             while ($row = mysqli_fetch_array($catquery)){
             echo "<li><a href="."ItemsPage.php?catID=".$row["catID"].">".$row["catName"]."</a></li>";
             }?>
                             <li><a href="OurCollection.php">Collection</a></li>
                            </ul>
                            
                         </li>
                        <li><a href = "#contact" data-toggle = "modal">Contact</a></li>
                    </ul>
                </div>
            </div> 
        </div> 
        <div class="container">
        <h3>Add Product</h3>
        <?php
        $con = mysqli_connect("localhost:3306", "waduser01", "st2220", "p1315787db");
        $recID   = $_POST['recordID'];
        $catID   = $_POST['catID'];
        $prodName = $_POST['Name'];
        $Desc1 = $_POST['Description1'];
        $Desc2 = $_POST['Description2'];       
        $Price = $_POST['Price'];
        $file = $_POST['file'];
        
        $filename = "img/" . $file;

        if (!mysqli_connect_errno($con)) { // connection to database is successful
         $catNameSearcher = mysqli_query($con, "SELECT * FROM category" .
                                               " WHERE `catID` = $catID");
            while ($row = mysqli_fetch_array($catNameSearcher)){
                $category = $row['catName'];
         
           $sqlQueryStr =
                   "INSERT INTO $category" .
                   "(recordID, catID, Name, Description1, Description2, Price, Image) " .
                   "VALUES " .
                   "('$recID', '$catID','$prodName','$Desc1', '$Desc2', '$Price', '$filename')";

               mysqli_query($con, $sqlQueryStr);
            }
               echo "Product Added.";
               mysqli_close($con);
       } else {
           echo "Failed to connect to MySQL: " . mysqli_connect_error();
          
       }
        
            
       ?>
        </div>
    </body>
</html>
