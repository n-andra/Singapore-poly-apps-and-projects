<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title></title>
        <style>
            body {
                text-align :center;
                font-family: monospace;
            }
            table {
                margin-left     :auto; 
                margin-right    :auto;
            }
            tr, td {
                border          :2px solid green;
            }
        </style>    
    </head>
    <body>
        <p>
        display with : 
        <a href="tableDisplay.php?row=2&col=6">2 by 6</a>,
        <a href="tableDisplay.php"            >3 by 4</a>,
        <a href="tableDisplay.php?row=4&col=3">4 by 3</a>,
        <a href="tableDisplay.php?row=6&col=2">6 by 2</a>
        </p>
        
        <?php
        
        $numOfRow = isset($_GET['row']) ? $_GET['row'] : 3;
        $numOfCol = 12/$numOfRow;
        
        
        $imgFilename = array("Aquarius.gif", "Aries.gif", "Cancer.gif", "Capricorn.gif",
            "Gemini.gif", "Leo.gif", "Libra.gif", "Pisces.gif", "Sagittarius.gif",
            "Scorpio.gif", "Taurus.gif", "Virgo.gif");
        
        echo '<table>';
        for ($row = 1; $row <= $numOfRow; $row++) {
            echo '<tr>';
            for ($col = 1; $col <= $numOfCol; $col++) {
                echo '<td>';
                echo "<img src='images/" . ($imgFilename[$numOfCol * ($row-1) + ($col-1     )]) . "'>";            
                echo '</td>';
            }
            echo '<tr>';   
        }        
        echo '<table>';
        ?>
    </body>
</html>
